-- Test if the user can update their own profile
-- Check RLS policies for profiles table

-- Let's check what happens when we try to update this specific user's profile
-- First, let's see the current profile data
SELECT id, email, username, full_name, birth_date, investment_profile, role 
FROM profiles 
WHERE email = 'tittow@gmail.com';