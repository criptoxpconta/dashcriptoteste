-- Test manual update for this user to see if RLS policies are working
-- This should work if the user is properly authenticated and RLS is working

-- Let's try to simulate what the frontend is doing
-- First check the RLS policies on profiles table
SELECT 
  schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check 
FROM pg_policies 
WHERE tablename = 'profiles';