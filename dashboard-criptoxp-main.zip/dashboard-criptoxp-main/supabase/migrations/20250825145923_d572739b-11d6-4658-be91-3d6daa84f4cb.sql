-- Create function to handle new investor account creation
CREATE OR REPLACE FUNCTION public.handle_new_investor_account()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Only create investor account for users with 'investor' role
  IF NEW.role = 'investor' THEN
    INSERT INTO public.investor_accounts (investor_id, display_name)
    VALUES (NEW.id, 'Conta Principal');
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger to automatically create investor accounts
CREATE TRIGGER on_investor_profile_created
  AFTER INSERT ON public.profiles
  FOR EACH ROW 
  WHEN (NEW.role = 'investor')
  EXECUTE FUNCTION public.handle_new_investor_account();

-- Also create investor account for existing investors who don't have one
INSERT INTO public.investor_accounts (investor_id, display_name)
SELECT p.id, 'Conta Principal'
FROM public.profiles p
LEFT JOIN public.investor_accounts ia ON p.id = ia.investor_id
WHERE p.role = 'investor' AND ia.id IS NULL;