-- Add initial_investment column to positions table
ALTER TABLE public.positions 
ADD COLUMN initial_investment numeric DEFAULT 0;