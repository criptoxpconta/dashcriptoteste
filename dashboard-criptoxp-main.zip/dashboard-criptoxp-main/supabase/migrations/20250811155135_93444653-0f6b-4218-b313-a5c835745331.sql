-- Inserir o ativo Dólar (USDT)
INSERT INTO public.assets (class, symbol, name) 
VALUES ('crypto', 'USDT', 'Dólar');