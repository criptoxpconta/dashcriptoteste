-- Fix infinite recursion in profiles RLS policies
-- Drop existing policies
DROP POLICY IF EXISTS "Admins can view and update all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Investors can view and update their own profile" ON public.profiles;

-- Create corrected policies without recursion
-- Users can view and update their own profile
CREATE POLICY "Users can manage their own profile" 
ON public.profiles 
FOR ALL 
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Admins can view all profiles (simplified approach)
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = auth.uid() AND p.role = 'admin'
  )
);

-- Admins can update all profiles 
CREATE POLICY "Admins can update all profiles" 
ON public.profiles 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = auth.uid() AND p.role = 'admin'
  )
);