-- Create profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role TEXT CHECK (role IN ('investor','admin')) NOT NULL DEFAULT 'investor',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create investor_accounts table
CREATE TABLE public.investor_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  investor_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.investor_accounts ENABLE ROW LEVEL SECURITY;

-- Create assets table
CREATE TABLE public.assets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  class TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;

-- Create positions table
CREATE TABLE public.positions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  asset_id UUID NOT NULL REFERENCES public.assets(id) ON DELETE CASCADE,
  quantity NUMERIC NOT NULL,
  avg_price NUMERIC NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.positions ENABLE ROW LEVEL SECURITY;

-- Create operations table
CREATE TABLE public.operations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('buy','sell','deposit','withdraw','fee','rebalance')) NOT NULL,
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  quantity NUMERIC,
  price NUMERIC,
  fee NUMERIC,
  notes TEXT,
  executed_at DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.operations ENABLE ROW LEVEL SECURITY;

-- Create monthly_results table
CREATE TABLE public.monthly_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12),
  return_percent NUMERIC NOT NULL,
  comment TEXT,
  created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(account_id, year, month)
);

-- Enable RLS
ALTER TABLE public.monthly_results ENABLE ROW LEVEL SECURITY;

-- Create balances_history table
CREATE TABLE public.balances_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  end_balance NUMERIC NOT NULL,
  source TEXT CHECK (source IN ('calc','manual','import')) NOT NULL DEFAULT 'manual',
  UNIQUE(account_id, date)
);

-- Enable RLS
ALTER TABLE public.balances_history ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX idx_investor_accounts_investor_id ON public.investor_accounts(investor_id);
CREATE INDEX idx_assets_symbol ON public.assets(symbol);
CREATE INDEX idx_positions_account_id ON public.positions(account_id);
CREATE INDEX idx_positions_asset_id ON public.positions(asset_id);
CREATE INDEX idx_operations_account_date ON public.operations(account_id, executed_at);

-- Policies for profiles
CREATE POLICY "Investors can view and update their own profile" ON public.profiles
  FOR ALL USING (auth.uid() = id);

CREATE POLICY "Admins can view and update all profiles" ON public.profiles
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for investor_accounts
CREATE POLICY "Investors can view their own accounts" ON public.investor_accounts
  FOR SELECT USING (investor_id = auth.uid());

CREATE POLICY "Admins can manage all accounts" ON public.investor_accounts
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for assets
CREATE POLICY "Assets are viewable by everyone" ON public.assets
  FOR SELECT USING (true);

CREATE POLICY "Only admins can manage assets" ON public.assets
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for positions
CREATE POLICY "Investors can view their own positions" ON public.positions
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all positions" ON public.positions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for operations
CREATE POLICY "Investors can view their own operations" ON public.operations
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all operations" ON public.operations
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for monthly_results
CREATE POLICY "Investors can view their own results" ON public.monthly_results
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all results" ON public.monthly_results
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for balances_history
CREATE POLICY "Investors can view their own balance history" ON public.balances_history
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all balance history" ON public.balances_history
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Function to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, role)
  VALUES (NEW.id, NEW.email, 'investor');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create profile
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert demo assets (no user dependency)
INSERT INTO public.assets (id, symbol, name, class) VALUES 
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'PETR4', 'Petrobras ON', 'acao'),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'VALE3', 'Vale ON', 'acao'),
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'IVVB11', 'iShares S&P 500', 'fii'),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'BTC', 'Bitcoin', 'cripto')
ON CONFLICT (symbol) DO NOTHING;