-- Create profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role TEXT CHECK (role IN ('investor','admin')) NOT NULL DEFAULT 'investor',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create investor_accounts table
CREATE TABLE public.investor_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  investor_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.investor_accounts ENABLE ROW LEVEL SECURITY;

-- Create assets table
CREATE TABLE public.assets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  class TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;

-- Create positions table
CREATE TABLE public.positions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  asset_id UUID NOT NULL REFERENCES public.assets(id) ON DELETE CASCADE,
  quantity NUMERIC NOT NULL,
  avg_price NUMERIC NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.positions ENABLE ROW LEVEL SECURITY;

-- Create operations table
CREATE TABLE public.operations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('buy','sell','deposit','withdraw','fee','rebalance')) NOT NULL,
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  quantity NUMERIC,
  price NUMERIC,
  fee NUMERIC,
  notes TEXT,
  executed_at DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.operations ENABLE ROW LEVEL SECURITY;

-- Create monthly_results table
CREATE TABLE public.monthly_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12),
  return_percent NUMERIC NOT NULL,
  comment TEXT,
  created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(account_id, year, month)
);

-- Enable RLS
ALTER TABLE public.monthly_results ENABLE ROW LEVEL SECURITY;

-- Create balances_history table
CREATE TABLE public.balances_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.investor_accounts(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  end_balance NUMERIC NOT NULL,
  source TEXT CHECK (source IN ('calc','manual','import')) NOT NULL DEFAULT 'manual',
  UNIQUE(account_id, date)
);

-- Enable RLS
ALTER TABLE public.balances_history ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX idx_investor_accounts_investor_id ON public.investor_accounts(investor_id);
CREATE INDEX idx_assets_symbol ON public.assets(symbol);
CREATE INDEX idx_positions_account_id ON public.positions(account_id);
CREATE INDEX idx_positions_asset_id ON public.positions(asset_id);
CREATE INDEX idx_operations_account_date ON public.operations(account_id, executed_at);

-- Policies for profiles
CREATE POLICY "Investors can view and update their own profile" ON public.profiles
  FOR ALL USING (auth.uid() = id);

CREATE POLICY "Admins can view and update all profiles" ON public.profiles
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for investor_accounts
CREATE POLICY "Investors can view their own accounts" ON public.investor_accounts
  FOR SELECT USING (investor_id = auth.uid());

CREATE POLICY "Admins can manage all accounts" ON public.investor_accounts
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for assets
CREATE POLICY "Assets are viewable by everyone" ON public.assets
  FOR SELECT USING (true);

CREATE POLICY "Only admins can manage assets" ON public.assets
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for positions
CREATE POLICY "Investors can view their own positions" ON public.positions
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all positions" ON public.positions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for operations
CREATE POLICY "Investors can view their own operations" ON public.operations
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all operations" ON public.operations
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for monthly_results
CREATE POLICY "Investors can view their own results" ON public.monthly_results
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all results" ON public.monthly_results
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Policies for balances_history
CREATE POLICY "Investors can view their own balance history" ON public.balances_history
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM public.investor_accounts 
      WHERE investor_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all balance history" ON public.balances_history
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Function to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, role)
  VALUES (NEW.id, NEW.email, 'investor');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create profile
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert seed data
-- Create admin user profile (you'll need to create this user in auth first)
INSERT INTO public.profiles (id, email, role) VALUES 
('00000000-0000-0000-0000-000000000000', 'admin@test.com', 'admin')
ON CONFLICT (id) DO NOTHING;

-- Create demo investor profile
INSERT INTO public.profiles (id, email, role) VALUES 
('11111111-1111-1111-1111-111111111111', 'investor@test.com', 'investor')
ON CONFLICT (id) DO NOTHING;

-- Create demo investor account
INSERT INTO public.investor_accounts (id, investor_id, display_name) VALUES 
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Carteira Principal')
ON CONFLICT (id) DO NOTHING;

-- Insert demo assets
INSERT INTO public.assets (id, symbol, name, class) VALUES 
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'PETR4', 'Petrobras ON', 'acao'),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'VALE3', 'Vale ON', 'acao'),
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'IVVB11', 'iShares S&P 500', 'fii'),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'BTC', 'Bitcoin', 'cripto')
ON CONFLICT (symbol) DO NOTHING;

-- Insert demo positions
INSERT INTO public.positions (account_id, asset_id, quantity, avg_price) VALUES 
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 100, 35.50),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'cccccccc-cccc-cccc-cccc-cccccccccccc', 50, 85.20),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'dddddddd-dddd-dddd-dddd-dddddddddddd', 25, 280.00),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 0.1, 200000.00)
ON CONFLICT DO NOTHING;

-- Insert demo monthly results (last 12 months)
INSERT INTO public.monthly_results (account_id, year, month, return_percent, comment, created_by) VALUES 
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 1, 2.5, 'Bom desempenho das ações', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 2, -1.2, 'Correção do mercado', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 3, 3.8, 'Rally do petróleo', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 4, 1.5, 'Estabilidade', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 5, -0.8, 'Volatilidade', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 6, 4.2, 'Excelente mês', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 7, 2.1, 'Crescimento steady', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 8, 1.8, 'Mês positivo', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 9, -2.1, 'Correção sazonal', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 10, 3.5, 'Recuperação forte', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 11, 2.8, 'Fim de ano positivo', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 2024, 12, 1.9, 'Fechamento do ano', '00000000-0000-0000-0000-000000000000')
ON CONFLICT (account_id, year, month) DO NOTHING;

-- Insert demo balance history (last 12 months)
INSERT INTO public.balances_history (account_id, date, end_balance) VALUES 
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-01-31', 100000),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-02-29', 98800),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-03-31', 102556),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-04-30', 104095),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-05-31', 103262),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-06-30', 107598),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-07-31', 109856),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-08-31', 111833),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-09-30', 109485),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-10-31', 113317),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-11-30', 116486),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2024-12-31', 118699)
ON CONFLICT (account_id, date) DO NOTHING;

-- Insert demo operations
INSERT INTO public.operations (account_id, type, asset_id, quantity, price, fee, notes, executed_at, created_by) VALUES 
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'buy', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 100, 35.50, 10.00, 'Compra inicial PETR4', '2024-01-15', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'buy', 'cccccccc-cccc-cccc-cccc-cccccccccccc', 50, 85.20, 15.00, 'Compra inicial VALE3', '2024-02-10', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'deposit', null, null, null, null, 'Aporte inicial', '2024-01-01', '00000000-0000-0000-0000-000000000000'),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'buy', 'dddddddd-dddd-dddd-dddd-dddddddddddd', 25, 280.00, 8.00, 'Diversificação internacional', '2024-03-15', '00000000-0000-0000-0000-000000000000')
ON CONFLICT DO NOTHING;