-- Create investor accounts for existing investors who don't have them
INSERT INTO public.investor_accounts (investor_id, display_name)
SELECT 
  p.id,
  'Conta Principal'
FROM public.profiles p
WHERE p.role = 'investor'
AND NOT EXISTS (
  SELECT 1 FROM public.investor_accounts ia 
  WHERE ia.investor_id = p.id
);

-- Create table for investment amounts
CREATE TABLE public.investment_amounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL,
  total_invested NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID NOT NULL,
  UNIQUE(account_id)
);

-- Enable RLS
ALTER TABLE public.investment_amounts ENABLE ROW LEVEL SECURITY;

-- Create policies for investment amounts
CREATE POLICY "Admins can manage all investment amounts" 
ON public.investment_amounts 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM profiles 
  WHERE profiles.id = auth.uid() 
  AND profiles.role = 'admin'
));

CREATE POLICY "Investors can view their own investment amounts" 
ON public.investment_amounts 
FOR SELECT 
USING (account_id IN (
  SELECT investor_accounts.id 
  FROM investor_accounts 
  WHERE investor_accounts.investor_id = auth.uid()
));

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION public.update_investment_amounts_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_investment_amounts_updated_at
BEFORE UPDATE ON public.investment_amounts
FOR EACH ROW
EXECUTE FUNCTION public.update_investment_amounts_updated_at();