-- Add account status to profiles table
ALTER TABLE public.profiles 
ADD COLUMN account_status text NOT NULL DEFAULT 'pending';

-- Add check constraint for valid status values
ALTER TABLE public.profiles 
ADD CONSTRAINT valid_account_status 
CHECK (account_status IN ('pending', 'approved', 'rejected'));

-- Update existing investor accounts to approved (they were already functional)
UPDATE public.profiles 
SET account_status = 'approved' 
WHERE role = 'investor';

-- Add indexes for better performance
CREATE INDEX idx_profiles_account_status ON public.profiles(account_status);
CREATE INDEX idx_profiles_role_status ON public.profiles(role, account_status);