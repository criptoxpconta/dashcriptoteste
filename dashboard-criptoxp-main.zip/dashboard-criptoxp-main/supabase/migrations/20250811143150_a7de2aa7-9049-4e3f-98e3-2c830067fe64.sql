-- Create storage bucket for operation images
INSERT INTO storage.buckets (id, name, public) VALUES ('operation-images', 'operation-images', true);

-- Add image_url column to operations table
ALTER TABLE public.operations ADD COLUMN image_url TEXT;

-- Create storage policies for operation images
CREATE POLICY "Admins can upload operation images" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'operation-images' AND 
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

CREATE POLICY "Anyone can view operation images" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'operation-images');

CREATE POLICY "Admins can delete operation images" 
ON storage.objects 
FOR DELETE 
USING (bucket_id = 'operation-images' AND 
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Add return_amount column to monthly_results for absolute values in R$
ALTER TABLE public.monthly_results ADD COLUMN return_amount NUMERIC;