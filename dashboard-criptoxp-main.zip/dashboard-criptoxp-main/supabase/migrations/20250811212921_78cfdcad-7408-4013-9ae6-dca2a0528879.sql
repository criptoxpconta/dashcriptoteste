-- Add birth_date and investment_profile fields to profiles table
ALTER TABLE public.profiles 
ADD COLUMN birth_date DATE,
ADD COLUMN investment_profile TEXT CHECK (investment_profile IN ('conservador', 'agressivo'));