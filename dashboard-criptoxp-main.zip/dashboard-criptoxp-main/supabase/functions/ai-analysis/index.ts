// supabase/functions/ai-analysis/index.ts
// Edge Function (Deno) para gerar análise de cripto via OpenAI Responses API
import "jsr:@supabase/functions-js/edge-runtime.d.ts";

type ReqBody = {
  symbol?: string;                     // Ex.: "BTCUSDT"
  interval?: string;                   // Ex.: "15m" | "1h" | ...
  format?: "plain" | "markdown";       // Formato de saída
  limit?: number;                      // Nº de velas (10..200)
  model?: string;                      // (opcional) sobrescreve o modelo por request
  debug?: boolean;                     // (opcional) devolve payload enviado à OpenAI
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // restrinja para seu domínio do lovable se quiser
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const VALID_INTERVALS = new Set([
  "1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M"
]);

// ---------- Util: label PT do timeframe ----------
function intervalLabelPt(iv: string): string {
  switch (iv) {
    case "1m": return "1 minuto";
    case "3m": return "3 minutos";
    case "5m": return "5 minutos";
    case "15m": return "15 minutos";
    case "30m": return "30 minutos";
    case "1h": return "1 hora";
    case "2h": return "2 horas";
    case "4h": return "4 horas";
    case "6h": return "6 horas";
    case "8h": return "8 horas";
    case "12h": return "12 horas";
    case "1d": return "Diário";
    case "3d": return "3 dias";
    case "1w": return "Semanal";
    case "1M": return "Mensal";
    default:   return iv;
  }
}

// ---------- Estilo/estrutura (100% PT-BR, sem abreviações) ----------
const STYLE_MD = (intervalLabel: string) => `
Linguagem: português do Brasil, sem palavras em inglês. Escreva tudo por extenso, **sem abreviações**.
Exceção: apenas **tickers** (ex.: BTCUSDT, USDT) podem permanecer como sigla.
Nunca use “TF”, “SL”, “TP”, “RR”, “EMA”, “RSI” etc. Se precisar citar um indicador, escreva por extenso (ex.: média móvel exponencial, índice de força relativa).

Formatação:
- Use **Markdown** com títulos de **nível 2 (##)** para cada seção.
- Use parágrafos curtos e claros, com quebras de linha.
- Valores sempre em **USDT**, com duas casas decimais. Não use BRL.

Seções (nessa ordem, exatamente com estes títulos):
## 🔍 Visão geral
## ⏱️ Cenário no período ${intervalLabel}
## 📈 Curto prazo
## 🧭 Longo prazo
## 🎯 Estratégia sugerida no período ${intervalLabel}
## 🧮 Plano de trade (USDT)
Apresente uma **tabela Markdown** com colunas: Parâmetro | Valor (USDT)
Linhas: Entrada | Stop | Alvo 1 | Alvo 2 | Relação risco-retorno
## ⚖️ Gestão de risco
## 🧪 Dados usados
Liste preço atual (lastPrice), máxima do dia (dayHigh), mínima do dia (dayLow), quantidade de velas (bars) e a fonte
## ⚠️ Aviso de risco

Regras obrigatórias:
- Checagem de sanidade: todos os níveis (entrada, stop, alvos, suportes e resistências) devem estar próximos da ordem de grandeza do preço atual (lastPrice).
- **Apenas USDT** (não use BRL). Não invente números se faltar dado; explique a limitação.
`.trim();

const STYLE_PLAIN = (intervalLabel: string) => `
Linguagem: português do Brasil, sem palavras em inglês. Sem abreviações. Exceção: apenas tickers (BTCUSDT, USDT).
Use texto simples, títulos em MAIÚSCULAS e parágrafos curtos. Valores em USDT com duas casas decimais.

Títulos (nessa ordem):
VISAO GERAL
CENARIO NO PERIODO ${intervalLabel}
CURTO PRAZO
LONGO PRAZO
ESTRATEGIA SUGERIDA NO PERIODO ${intervalLabel}
PLANO DE TRADE (USDT) — lista com Entrada, Stop, Alvo 1, Alvo 2 e Relação risco-retorno
GESTAO DE RISCO
DADOS USADOS — lastPrice, dayHigh, dayLow, bars, fonte
AVISO DE RISCO

Regras:
- Checagem de sanidade com base em lastPrice. Apenas USDT. Sem inventar números.
`.trim();

const sysPrompt = (format: "plain" | "markdown", intervalLabel: string) =>
  "Você é um analista de criptomoedas. Responda SEMPRE em português do Brasil e sem abreviações (exceto tickers, como BTCUSDT e USDT).\n" +
  (format === "markdown" ? STYLE_MD(intervalLabel) : STYLE_PLAIN(intervalLabel));

// --------- Extrator robusto de texto do Responses API ---------
function extractTextDeep(json: any): string {
  if (!json) return "";

  // 1) Campo de conveniência da Responses API
  if (typeof json.output_text === "string" && json.output_text.trim()) {
    return json.output_text.trim();
  }

  // 2) Estrutura típica: output[].content[].text (ou objetos com {type: '*text', text: '...'})
  const bag: string[] = [];
  const visit = (node: any) => {
    if (!node) return;
    if (typeof node === "string") return;

    if (Array.isArray(node)) {
      for (const item of node) visit(item);
      return;
    }

    if (typeof node === "object") {
      if (typeof (node as any).text === "string") {
        const t = (node as any).text.trim();
        if (t && (!node.type || /text/i.test(String(node.type)))) {
          bag.push(t);
        }
      }
      for (const k of Object.keys(node)) {
        if (k === "_parent") continue;
        visit((node as any)[k]);
      }
      return;
    }
  };

  if (json.output) visit(json.output);
  if (bag.length) return bag.join("\n"); // mantém quebras se vierem em blocos

  // 3) Compat com chat: choices[0].message.content
  const mc = json?.choices?.[0]?.message?.content;
  if (typeof mc === "string" && mc.trim()) return mc.trim();

  // 4) Nada encontrado
  return "";
}

Deno.serve(async (req) => {
  // CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method Not Allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
  if (!OPENAI_API_KEY) {
    return new Response(JSON.stringify({ error: "OPENAI_API_KEY ausente" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // ---------- Input ----------
  let bodyIn: ReqBody = {};
  try { bodyIn = await req.json(); } catch {}

  const symbol = (bodyIn.symbol || "BTCUSDT").toUpperCase();
  const interval = VALID_INTERVALS.has(bodyIn.interval || "") ? bodyIn.interval! : "15m";
  const intervalLabel = intervalLabelPt(interval);
  const format: "plain" | "markdown" = bodyIn.format === "plain" ? "plain" : "markdown";
  const limit = Math.min(Math.max(Number(bodyIn.limit ?? 50), 10), 200);
  const debug = !!bodyIn.debug;

  // Modelo final (prioridade: body.model -> ENV OPENAI_MODEL -> alias estável)
  const model = (bodyIn.model || Deno.env.get("OPENAI_MODEL") || "gpt-5-nano").trim();

  // ---------- Dados da Binance (Futures USDT-M) ----------
  const priceUrl = `https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol}`;
  const t24hUrl  = `https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=${symbol}`;
  const klUrl    = `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;

  try {
    const [pr, t24, kl] = await Promise.all([ fetch(priceUrl), fetch(t24hUrl), fetch(klUrl) ]);

    if (!pr.ok || !t24.ok || !kl.ok) {
      const msg = `Binance error: price=${pr.status} t24h=${t24.status} klines=${kl.status}`;
      return new Response(JSON.stringify({ error: msg }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const priceData = await pr.json() as { symbol: string; price: string };
    const t24hData  = await t24.json() as any;
    const klines    = await kl.json() as any[];

    const ohlc = klines.map((k) => ({
      t: k[0], o: Number(k[1]), h: Number(k[2]), l: Number(k[3]), c: Number(k[4]), v: Number(k[5]), ct: k[6],
    }));

    const lastPrice = Number(priceData?.price ?? "0");
    const dayHigh   = Number(t24hData?.highPrice ?? "0");
    const dayLow    = Number(t24hData?.lowPrice  ?? "0");

    const ctx = {
      source: "Binance Futures USDT-M",
      symbol,
      interval,
      lastPrice,
      dayHigh,
      dayLow,
      bars: ohlc.length,
    };

    // ---------- Prompt final (100% PT, sem abreviações) ----------
    const instructions = sysPrompt(format, intervalLabel);
    const userText =
      `Baseie-se APENAS nos DADOS-BASE (JSON) abaixo, escrevendo em português do Brasil e sem abreviações (exceto tickers). ` +
      `Produza análise de curto prazo e de longo prazo e indique uma estratégia no período "${intervalLabel}". ` +
      `Envie também um plano de trade completo (entrada, stop, alvos) em USDT, seguindo as seções e regras pedidas.\n` +
      `DADOS-BASE:\n${JSON.stringify({ ...ctx, sample: ohlc.slice(-20) })}`;

    // ---------- OpenAI Responses API ----------
    const isGPT5 = /^gpt-5\b/i.test(model);
    const respBody: any = {
      model,
      instructions, // substitui o "system"
      input: [
        {
          role: "user",
          content: [{ type: "input_text", text: userText }],
        },
      ],
      // Para Responses API use max_output_tokens
      max_output_tokens: 1200,
      // Evita consumo só em "reasoning" nos GPT-5
      reasoning: { effort: "minimal" }
    };
    if (!isGPT5) {
      // Para modelos não-GPT-5, se desejar sampling:
      respBody.temperature = 0.45;
      respBody.top_p = 0.95;
    }

    const r = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(respBody),
    });

    if (!r.ok) {
      const text = await r.text(); // repassa o erro real da OpenAI
      return new Response(JSON.stringify({
        error: "OpenAI error",
        status: r.status,
        model,
        detail: text,
        debug: debug ? { respBody } : undefined,
      }), {
        status: r.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const json = await r.json();

    // ---------- Extração robusta do texto ----------
    const content = extractTextDeep(json);

    return new Response(JSON.stringify({
      content,                                   // <- sempre string (pode ser "" se realmente vazio)
      meta: { model, usage: json?.usage ?? null },
      used: ctx,
      debug: debug ? { respBody } : undefined,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e) {
    return new Response(JSON.stringify({
      error: "Request failed",
      detail: String(e),
      stack: (e as Error)?.stack,
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
