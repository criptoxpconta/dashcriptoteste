import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/hooks/useAuth";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { Suspense, lazy } from "react";

// Páginas críticas
import Index from "./pages/Index";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import NotFound from "./pages/NotFound";

// Investor (lazy)
const InvestorDashboard = lazy(() => import("./pages/investor/Dashboard"));
const InvestorResults = lazy(() => import("./pages/investor/Results"));
const InvestorTransactions = lazy(() => import("./pages/investor/Transactions"));
const InvestorOperations = lazy(() => import("./pages/investor/Operations"));
const InvestorSupport = lazy(() => import("./pages/investor/Support"));
const InvestorCriptoXPIA = lazy(() => import("./pages/investor/CriptoXPIA"));

// Admin (lazy)
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const Investors = lazy(() => import("./pages/admin/Investors"));
const AdminOperations = lazy(() => import("./pages/admin/Operations"));
const AdminResults = lazy(() => import("./pages/admin/Results"));
const AdminTransactions = lazy(() => import("./pages/admin/Transactions"));
const Withdrawals = lazy(() => import("./pages/admin/Withdrawals"));
const InvestmentValue = lazy(() => import("./pages/admin/InvestmentValue"));
const Messages = lazy(() => import("./pages/admin/Messages"));
const ManageAssets = lazy(() => import("./pages/admin/ManageAssets"));

// >>> ADIÇÃO: Settings (lazy)
const AccountSettings = lazy(() => import("./pages/AccountSettings"));

const PageLoader = () => (
  <div className="min-h-[50vh] flex items-center justify-center">
    <div className="text-center space-y-2">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      <p className="text-sm text-muted-foreground">Carregando...</p>
    </div>
  </div>
);

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />

              <Route
                path="/app"
                element={
                  <ProtectedRoute>
                    <AppLayout />
                  </ProtectedRoute>
                }
              >
                {/* INVESTIDOR */}
                <Route
                  path="investidor"
                  element={
                    <ProtectedRoute requiredRole="investor">
                      <Suspense fallback={<PageLoader />}>
                        <InvestorDashboard />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="investidor/resultados"
                  element={
                    <ProtectedRoute requiredRole="investor">
                      <Suspense fallback={<PageLoader />}>
                        <InvestorResults />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="investidor/operacoes"
                  element={
                    <ProtectedRoute requiredRole="investor">
                      <Suspense fallback={<PageLoader />}>
                        <InvestorOperations />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="investidor/transacoes"
                  element={
                    <ProtectedRoute requiredRole="investor">
                      <Suspense fallback={<PageLoader />}>
                        <InvestorTransactions />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="investidor/suporte"
                  element={
                    <ProtectedRoute requiredRole="investor">
                      <Suspense fallback={<PageLoader />}>
                        <InvestorSupport />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="investidor/criptoxp-ia"
                  element={
                    <ProtectedRoute requiredRole="investor">
                      <Suspense fallback={<PageLoader />}>
                        <InvestorCriptoXPIA />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />

                {/* >>> ADIÇÃO: SETTINGS (qualquer usuário logado) */}
                <Route
                  path="settings"
                  element={
                    <ProtectedRoute>
                      <Suspense fallback={<PageLoader />}>
                        <AccountSettings />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />

                {/* ADMIN */}
                <Route
                  path="admin"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <AdminDashboard />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/investors"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <Investors />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/operations"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <AdminOperations />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/results"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <AdminResults />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/transactions"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <AdminTransactions />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/withdrawals"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <Withdrawals />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/investment-value"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <InvestmentValue />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/messages"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <Messages />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/manage-assets"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <Suspense fallback={<PageLoader />}>
                        <ManageAssets />
                      </Suspense>
                    </ProtectedRoute>
                  }
                />
              </Route>

              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
