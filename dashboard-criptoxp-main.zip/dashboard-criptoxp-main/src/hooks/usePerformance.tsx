import { useEffect, useCallback } from 'react';

// Hook for performance monitoring and optimization
export function usePerformance() {
  // Debounce function for heavy operations
  const debounce = useCallback((func: Function, wait: number) => {
    let timeout: NodeJS.Timeout;
    return function executedFunction(...args: any[]) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }, []);

  // Throttle function for scroll and resize events
  const throttle = useCallback((func: Function, limit: number) => {
    let inThrottle: boolean;
    return function executedFunction(...args: any[]) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }, []);

  // Optimize images loading
  const optimizeImages = useCallback(() => {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          img.src = img.dataset.src || '';
          img.removeAttribute('data-src');
          imageObserver.unobserve(img);
        }
      });
    });

    images.forEach((img) => imageObserver.observe(img));
    
    return () => imageObserver.disconnect();
  }, []);

  // Prefetch critical resources
  const prefetchResource = useCallback((url: string, type: 'script' | 'style' | 'image' = 'script') => {
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.href = url;
    if (type === 'style') link.as = 'style';
    if (type === 'script') link.as = 'script';
    if (type === 'image') link.as = 'image';
    document.head.appendChild(link);
  }, []);

  // Monitor Core Web Vitals
  const monitorWebVitals = useCallback(() => {
    if ('web-vital' in window) {
      // This would integrate with a real monitoring service
      console.log('Web Vitals monitoring enabled');
    }
  }, []);

  useEffect(() => {
    optimizeImages();
    monitorWebVitals();
  }, [optimizeImages, monitorWebVitals]);

  return {
    debounce,
    throttle,
    optimizeImages,
    prefetchResource,
    monitorWebVitals
  };
}