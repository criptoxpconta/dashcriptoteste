import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChartMonthly } from '@/components/charts/BarChartMonthly';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  TrendingUp, 
  Calendar,
  Loader2 
} from 'lucide-react';

interface MonthlyResult {
  id: string;
  year: number;
  month: number;
  return_percent: number;
  return_amount: number;
  comment?: string;
  created_at: string;
}

export default function InvestorResults() {
  const { user } = useAuth();
  const [monthlyResults, setMonthlyResults] = useState<MonthlyResult[]>([]);
  const [chartData, setChartData] = useState<Array<{ month: string; return: number }>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadResults();
    }
  }, [user]);

  const loadResults = async () => {
    try {
      setLoading(true);

      // Get investor account
      const { data: accounts } = await supabase
        .from('investor_accounts')
        .select('id')
        .eq('investor_id', user?.id)
        .single();

      if (!accounts) {
        setLoading(false);
        return;
      }

      // Load monthly results
      const { data: results } = await supabase
        .from('monthly_results')
        .select('*')
        .eq('account_id', accounts.id)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      if (results) {
        setMonthlyResults(results);
        
        // Prepare chart data (reverse order for chart)
        const chartResults = [...results].reverse().map(item => ({
          month: `${item.year}-${String(item.month).padStart(2, '0')}`,
          return: item.return_percent
        }));
        
        setChartData(chartResults);
      }

    } catch (error) {
      console.error('Error loading results:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  const getMonthName = (month: number) => {
    const months = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    return months[month - 1];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Resultados Mensais</h1>
        <p className="text-muted-foreground">
          Acompanhe a performance detalhada dos seus investimentos mês a mês
        </p>
      </div>

      {/* Monthly Results Chart */}
      <Card className="card-glass">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Gráfico de Resultados Mensais
          </CardTitle>
          <CardDescription>
            Performance mensal em percentual
          </CardDescription>
        </CardHeader>
        <CardContent>
          <BarChartMonthly data={chartData} />
        </CardContent>
      </Card>

      {/* Results Table */}
      <Card className="card-glass">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Histórico Detalhado
          </CardTitle>
          <CardDescription>
            Resumo completo de todos os resultados mensais
          </CardDescription>
        </CardHeader>
        <CardContent>
          {monthlyResults.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhum resultado encontrado</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Mês/Ano</TableHead>
                  <TableHead>Rentabilidade (%)</TableHead>
                  <TableHead>Valor (R$)</TableHead>
                  <TableHead>Observações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {monthlyResults.map((result) => (
                  <TableRow key={result.id}>
                    <TableCell className="font-medium">
                      {getMonthName(result.month)} / {result.year}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={result.return_percent >= 0 ? "default" : "destructive"}
                      >
                        {formatPercent(result.return_percent)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={result.return_amount >= 0 ? "text-green-600" : "text-red-600"}>
                        {formatCurrency(result.return_amount || 0)}
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {result.comment || '-'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}