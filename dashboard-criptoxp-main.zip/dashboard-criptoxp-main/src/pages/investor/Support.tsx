import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { MessageSquare, Plus, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface SupportTicket {
  id: string;
  title: string;
  subject: string;
  status: 'Aberto' | 'Resolvido';
  created_at: string;
  updated_at: string;
  lastMessage?: {
    created_at: string;
    author_role: 'investor' | 'admin';
  };
}

interface SupportMessage {
  id: string;
  message: string;
  author_role: 'investor' | 'admin';
  created_at: string;
  profiles?: {
    full_name?: string;
    email: string;
  };
}

export default function Support() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewTicket, setShowNewTicket] = useState(false);
  
  // Form states
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      loadTickets();
    }
  }, [user]);

  const loadTickets = async () => {
    try {
      const { data: ticketsData, error } = await supabase
        .from('support_tickets')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get last message for each ticket
      const ticketsWithLastMessage = [];
      for (const ticket of ticketsData || []) {
        // Get last message for this ticket
        const { data: lastMessage } = await supabase
          .from('support_messages')
          .select('created_at, author_role')
          .eq('ticket_id', ticket.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .single();
        
        ticketsWithLastMessage.push({
          ...ticket,
          lastMessage
        });
      }

      setTickets(ticketsWithLastMessage as SupportTicket[]);
    } catch (error) {
      console.error('Error loading tickets:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os tickets.",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async (ticketId: string) => {
    try {
      const { data, error } = await supabase
        .from('support_messages')
        .select('*')
        .eq('ticket_id', ticketId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages((data || []) as SupportMessage[]);
    } catch (error) {
      console.error('Error loading messages:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar as mensagens.",
      });
    }
  };

  const createTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !title.trim() || !subject.trim()) return;

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('support_tickets')
        .insert({
          title: title.trim(),
          subject: subject.trim(),
          investor_id: user.id,
        });

      if (error) throw error;

      toast({
        title: "Ticket criado!",
        description: "Seu ticket foi criado com sucesso.",
      });
      
      setTitle('');
      setSubject('');
      setShowNewTicket(false);
      loadTickets();
    } catch (error) {
      console.error('Error creating ticket:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível criar o ticket.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedTicket || !newMessage.trim() || selectedTicket.status === 'Resolvido') return;

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('support_messages')
        .insert({
          ticket_id: selectedTicket.id,
          author_id: user.id,
          author_role: 'investor',
          message: newMessage.trim(),
        });

      if (error) throw error;

      setNewMessage('');
      loadMessages(selectedTicket.id);
      toast({
        title: "Mensagem enviada!",
        description: "Sua mensagem foi enviada com sucesso.",
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível enviar a mensagem.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleTicketClick = (ticket: SupportTicket) => {
    setSelectedTicket(ticket);
    loadMessages(ticket.id);
    setShowNewTicket(false);
  };

  const getStatusColor = (status: string) => {
    return status === 'Aberto' ? 'bg-green-500/10 text-green-500' : 'bg-gray-500/10 text-gray-500';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Suporte</h1>
        <Button 
          onClick={() => {
            setShowNewTicket(true);
            setSelectedTicket(null);
          }}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Novo Ticket
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Meus Tickets
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {tickets.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  Nenhum ticket encontrado
                </p>
              ) : (
                tickets.map((ticket) => (
                  <div
                    key={ticket.id}
                    onClick={() => handleTicketClick(ticket)}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-muted/50 ${
                      selectedTicket?.id === ticket.id ? 'bg-muted' : ''
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-medium text-sm truncate">{ticket.title}</h3>
                        <Badge className={getStatusColor(ticket.status)}>
                          {ticket.status}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {format(new Date(ticket.created_at), 'dd/MM/yyyy', { locale: ptBR })}
                      </div>
                      
                      {ticket.lastMessage && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <MessageSquare className="h-3 w-3" />
                          Última: {ticket.lastMessage.author_role === 'admin' ? 'Admin' : 'Você'} • {format(new Date(ticket.lastMessage.created_at), 'dd/MM HH:mm', { locale: ptBR })}
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2">
          {showNewTicket && (
            <Card>
              <CardHeader>
                <CardTitle>Novo Ticket de Suporte</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={createTicket} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Título</label>
                    <Input
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Descreva brevemente o problema"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Descrição</label>
                    <Textarea
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="Descreva detalhadamente o problema ou questão"
                      rows={6}
                      required
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" disabled={submitting}>
                      {submitting ? "Criando..." : "Criar Ticket"}
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowNewTicket(false)}
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {selectedTicket && (
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{selectedTicket.title}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      Criado em {format(new Date(selectedTicket.created_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                    </p>
                  </div>
                  <Badge className={getStatusColor(selectedTicket.status)}>
                    {selectedTicket.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="whitespace-pre-wrap">{selectedTicket.subject}</p>
                </div>

                {/* Messages */}
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`p-3 rounded-lg ${
                        message.author_role === 'investor' 
                          ? 'bg-primary/10 ml-8' 
                          : 'bg-muted mr-8'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">
                          {message.author_role === 'investor' ? 'Você' : 'Administrador'}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(message.created_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                        </span>
                      </div>
                      <p className="whitespace-pre-wrap">{message.message}</p>
                    </div>
                  ))}
                </div>

                {/* Send Message */}
                {selectedTicket.status === 'Aberto' && (
                  <form onSubmit={sendMessage} className="space-y-3">
                    <Textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Digite sua mensagem..."
                      rows={3}
                      required
                    />
                    <Button type="submit" disabled={submitting || !newMessage.trim()}>
                      {submitting ? "Enviando..." : "Enviar Mensagem"}
                    </Button>
                  </form>
                )}

                {selectedTicket.status === 'Resolvido' && (
                  <div className="p-3 bg-gray-500/10 rounded-lg text-center">
                    <p className="text-muted-foreground">
                      Este ticket foi resolvido e não aceita mais mensagens.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {!showNewTicket && !selectedTicket && (
            <Card>
              <CardContent className="text-center py-8">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">Selecione um ticket</h3>
                <p className="text-muted-foreground">
                  Escolha um ticket da lista ao lado para visualizar as mensagens ou crie um novo ticket.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}