import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { CardKPI } from '@/components/ui/card-kpi';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChartEvolution } from '@/components/charts/LineChartEvolution';
import { DonutAllocation } from '@/components/charts/DonutAllocation';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  DollarSign, 
  PieChart, 
  Calendar,
  Loader2 
} from 'lucide-react';
import { QuoteCard } from '@/components/quotes/QuoteCard';
import { fetchQuote } from '@/api/quotes';

interface DashboardData {
  totalInvested: number;
  currentBalance: number;
  monthlyReturn: number;
  ytdReturn: number;
  numAssets: number;
  balanceHistory: Array<{ date: string; value: number }>;
  monthlyResults: Array<{ month: string; return: number }>;
  allocation: Array<{ name: string; value: number; percentage: number }>;
}

export default function InvestorDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Get investor account
      const { data: accounts } = await supabase
        .from('investor_accounts')
        .select('id')
        .eq('investor_id', user?.id)
        .single();

      if (!accounts) {
        setLoading(false);
        return;
      }

      const accountId = accounts.id;

      // Load balance history
      const { data: balanceHistory } = await supabase
        .from('balances_history')
        .select('date, end_balance')
        .eq('account_id', accountId)
        .order('date', { ascending: true });

      // Load monthly results
      const { data: monthlyResults } = await supabase
        .from('monthly_results')
        .select('year, month, return_percent, return_amount')
        .eq('account_id', accountId)
        .order('year', { ascending: true })
        .order('month', { ascending: true });

      // Load positions with assets
      const { data: positions } = await supabase
        .from('positions')
        .select(`
          quantity,
          avg_price,
          assets!inner(symbol, name, class)
        `)
        .eq('account_id', accountId);

      // Get actual invested amount from investment_amounts table
      const { data: investmentData } = await supabase
        .from('investment_amounts')
        .select('total_invested')
        .eq('account_id', accountId)
        .maybeSingle();
      
      const totalInvested = investmentData?.total_invested || 0;

      // Get total withdrawals with dates
      const { data: withdrawalsData } = await supabase
        .from('withdrawals')
        .select('amount, year, month')
        .eq('account_id', accountId);
      
      const totalWithdrawals = withdrawalsData?.reduce((sum, withdrawal) => sum + Number(withdrawal.amount), 0) || 0;

      // Get all monthly results amounts (sum all months, not just last one)
      const { data: allResultsData } = await supabase
        .from('monthly_results')
        .select('return_amount')
        .eq('account_id', accountId);
      
      const totalReturnsAmount = allResultsData?.reduce((sum, result) => sum + (Number(result.return_amount) || 0), 0) || 0;

      // Calculate current value of assets based on live quotes
      let assetsValue = 0;
      
      if (positions && positions.length > 0) {
        for (const position of positions) {
          const assetSymbol = position.assets?.symbol;
          if (assetSymbol) {
            let price = 0;
            if (assetSymbol === 'BTC') {
              const response = await fetchQuote('btcbrl');
              if (response.success && response.data) {
                price = response.data.price;
              }
            } else if (assetSymbol === 'USDT' || assetSymbol === 'USD') {
              const response = await fetchQuote('usdbrl');
              if (response.success && response.data) {
                price = response.data.price;
              }
            }
            
            assetsValue += position.quantity * price;
          }
        }
      }

      // Calculate current balance: Valor dos ativos + Retornos - Saques (mesma lógica do admin)
      const currentBalance = assetsValue + totalReturnsAmount - totalWithdrawals;
      
      // Debug log to check values
      console.log('Dashboard calculation debug:', {
        totalInvested,
        totalReturnsAmount,
        totalWithdrawals,
        assetsValue,
        currentBalance,
        accountId
      });
      
      const lastMonthResult = monthlyResults?.[monthlyResults.length - 1]?.return_percent || 0;
      const ytdReturn = monthlyResults?.reduce((sum, result) => sum + result.return_percent, 0) || 0;

      // Prepare chart data - Cumulative balance from June to current month
      const chartBalanceHistory = (() => {
        if (!investmentData) return [];
        
        const months = [
          { month: 6, year: 2025, name: 'Jun' },
          { month: 7, year: 2025, name: 'Jul' },
          { month: 8, year: 2025, name: 'Ago' }
        ];
        
        const chartData = [];
        let runningBalance = totalInvested; // Start with total invested
        
        for (const monthInfo of months) {
          // Get the specific result for this month
          const monthResult = monthlyResults?.find(result => 
            result.year === monthInfo.year && result.month === monthInfo.month
          );
          
          // Add the return for this month if it exists
          if (monthResult) {
            runningBalance += Number(monthResult.return_amount) || 0;
          }
          
          // Subtract withdrawals for this month
          const monthWithdrawals = withdrawalsData?.filter(withdrawal => 
            withdrawal.year === monthInfo.year && withdrawal.month === monthInfo.month
          ).reduce((sum, withdrawal) => sum + Number(withdrawal.amount), 0) || 0;
          
          runningBalance -= monthWithdrawals;
          
          chartData.push({
            date: `${monthInfo.year}-${String(monthInfo.month).padStart(2, '0')}-01`,
            value: Math.max(0, runningBalance)
          });
        }
        
        return chartData;
      })();

      const chartMonthlyResults = monthlyResults?.map(item => ({
        month: `${item.year}-${String(item.month).padStart(2, '0')}`,
        return: item.return_percent
      })) || [];

      // Calculate allocation
      const allocation = positions?.map(position => {
        const value = position.quantity * position.avg_price;
        const percentage = (value / currentBalance) * 100;
        return {
          name: position.assets.symbol,
          value,
          percentage
        };
      }) || [];

      setData({
        totalInvested,
        currentBalance,
        monthlyReturn: lastMonthResult,
        ytdReturn,
        numAssets: positions?.length || 0,
        balanceHistory: chartBalanceHistory,
        monthlyResults: chartMonthlyResults,
        allocation
      });

    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Nenhum dado encontrado. Entre em contato com o administrador.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 lg:space-y-6 pb-20 lg:pb-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-xl lg:text-3xl font-bold">Dashboard</h1>
        <p className="text-sm lg:text-base text-muted-foreground">
          Acompanhe a performance dos seus investimentos
        </p>
      </div>

      {/* Quote Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 lg:gap-4">
        <QuoteCard title="Dólar (USD/BRL)" endpoint="usdbrl" />
        <QuoteCard title="Bitcoin (BTC/BRL)" endpoint="btcbrl" />
      </div>

      {/* Recent Updates */}
      <Card className="card-glass border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Últimas Atualizações
          </CardTitle>
          <CardDescription>
            Atividades recentes realizadas pelo administrador
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data.monthlyResults.length > 0 && (
              <div className="flex items-center justify-between p-3 bg-accent/30 rounded-lg">
                <div>
                  <p className="font-medium">Novo resultado mensal</p>
                  <p className="text-sm text-muted-foreground">
                    Resultado do mês {data.monthlyResults[data.monthlyResults.length - 1]?.month}
                  </p>
                </div>
                <Badge variant={data.monthlyReturn >= 0 ? "default" : "destructive"}>
                  {formatPercent(data.monthlyReturn)}
                </Badge>
              </div>
            )}
            
            <div className="flex items-center justify-between p-3 bg-accent/30 rounded-lg">
              <div>
                <p className="font-medium">Saldo atualizado</p>
                <p className="text-sm text-muted-foreground">
                  Última atualização de patrimônio
                </p>
              </div>
              <span className="font-medium">{formatCurrency(data.currentBalance)}</span>
            </div>

            {data.numAssets > 0 && (
              <div className="flex items-center justify-between p-3 bg-accent/30 rounded-lg">
                <div>
                  <p className="font-medium">Carteira configurada</p>
                  <p className="text-sm text-muted-foreground">
                    Ativos na sua carteira
                  </p>
                </div>
                <span className="font-medium">{data.numAssets} ativos</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <CardKPI
          title="Total Investido"
          value={formatCurrency(data.totalInvested)}
          icon={DollarSign}
        />
        <CardKPI
          title="Saldo Atual"
          value={formatCurrency(data.currentBalance)}
          change={`Ganho: ${formatCurrency(data.currentBalance - data.totalInvested)}`}
          changeType={data.currentBalance >= data.totalInvested ? 'positive' : 'negative'}
          icon={TrendingUp}
        />
        <CardKPI
          title="Retorno Mensal"
          value={formatPercent(data.monthlyReturn)}
          changeType={data.monthlyReturn >= 0 ? 'positive' : 'negative'}
          icon={Calendar}
        />
        <CardKPI
          title="Número de Ativos"
          value={data.numAssets.toString()}
          icon={PieChart}
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        <Card className="card-glass">
          <CardHeader className="pb-3 lg:pb-6">
            <CardTitle className="text-lg lg:text-xl">Evolução do Patrimônio</CardTitle>
            <CardDescription className="text-sm">
              Crescimento do investimento ao longo do tempo
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="h-64 lg:h-80">
              <LineChartEvolution data={data.balanceHistory} />
            </div>
          </CardContent>
        </Card>

        <Card className="card-glass">
          <CardHeader className="pb-3 lg:pb-6">
            <CardTitle className="text-lg lg:text-xl">Alocação por Ativo</CardTitle>
            <CardDescription className="text-sm">
              Distribuição percentual dos investimentos
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="h-64 lg:h-80">
              <DonutAllocation data={data.allocation} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
        <Card className="card-glass">
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg">Rentabilidade YTD</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-xl lg:text-2xl font-bold">
              <Badge 
                variant={data.ytdReturn >= 0 ? "default" : "destructive"}
                className="text-sm lg:text-lg px-2 lg:px-3 py-1"
              >
                {formatPercent(data.ytdReturn)}
              </Badge>
            </div>
            <p className="text-xs lg:text-sm text-muted-foreground mt-2">
              Acumulado no ano
            </p>
          </CardContent>
        </Card>

        <Card className="card-glass">
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg">Último Mês</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-xl lg:text-2xl font-bold">
              <Badge 
                variant={data.monthlyReturn >= 0 ? "default" : "destructive"}
                className="text-sm lg:text-lg px-2 lg:px-3 py-1"
              >
                {formatPercent(data.monthlyReturn)}
              </Badge>
            </div>
            <p className="text-xs lg:text-sm text-muted-foreground mt-2">
              Performance do mês anterior
            </p>
          </CardContent>
        </Card>

        <Card className="card-glass">
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg">Total de Ativos</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-xl lg:text-2xl font-bold text-primary">
              {data.numAssets}
            </div>
            <p className="text-xs lg:text-sm text-muted-foreground mt-2">
              Ativos na carteira
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}