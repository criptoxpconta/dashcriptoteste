import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  ArrowDownUp,
  TrendingUp,
  TrendingDown,
  Loader2 
} from 'lucide-react';

interface Transaction {
  id: string;
  type: 'monthly_result' | 'withdrawal';
  date: string;
  amount: number;
  description: string;
  balance?: number;
}

export default function InvestorTransactions() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => {
    if (user) {
      loadTransactions();
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      loadTransactions();
    }
  }, [startDate, endDate]);

  const loadTransactions = async () => {
    try {
      setLoading(true);

      // Get investor account
      const { data: accounts } = await supabase
        .from('investor_accounts')
        .select('id')
        .eq('investor_id', user?.id)
        .single();

      if (!accounts) {
        setLoading(false);
        return;
      }

      const accountId = accounts.id;

      // Get monthly results
      const { data: monthlyResults } = await supabase
        .from('monthly_results')
        .select('id, year, month, return_amount, created_at')
        .eq('account_id', accountId)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      // Get withdrawals
      const { data: withdrawals } = await supabase
        .from('withdrawals')
        .select('id, year, month, amount, created_at, notes')
        .eq('account_id', accountId)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      // Combine and sort transactions
      const transactionList: Transaction[] = [];

      monthlyResults?.forEach(result => {
        const transactionDate = new Date(result.year, result.month - 1, 1);
        
        // Aplicar filtro de data
        if (startDate && transactionDate < new Date(startDate)) return;
        if (endDate && transactionDate > new Date(endDate)) return;

        transactionList.push({
          id: result.id,
          type: 'monthly_result',
          date: `${result.year}-${String(result.month).padStart(2, '0')}-01`,
          amount: Number(result.return_amount) || 0,
          description: `Retorno do mês ${result.month}/${result.year}`
        });
      });

      withdrawals?.forEach(withdrawal => {
        const transactionDate = new Date(withdrawal.year, withdrawal.month - 1, 1);
        
        // Aplicar filtro de data
        if (startDate && transactionDate < new Date(startDate)) return;
        if (endDate && transactionDate > new Date(endDate)) return;

        transactionList.push({
          id: withdrawal.id,
          type: 'withdrawal',
          date: `${withdrawal.year}-${String(withdrawal.month).padStart(2, '0')}-01`,
          amount: -Number(withdrawal.amount),
          description: withdrawal.notes || `Saque ${withdrawal.month}/${withdrawal.year}`
        });
      });

      // Sort by date descending
      transactionList.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      setTransactions(transactionList);

    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const clearFilters = () => {
    setStartDate('');
    setEndDate('');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Histórico de Transações</h1>
        <p className="text-muted-foreground">
          Acompanhe todos os retornos mensais e saques realizados
        </p>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Data início</label>
              <Input 
                type="date" 
                value={startDate} 
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Data fim</label>
              <Input 
                type="date" 
                value={endDate} 
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>

            <div className="flex items-end">
              <Button variant="outline" onClick={clearFilters}>
                Limpar Filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card className="card-glass">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowDownUp className="h-5 w-5" />
            Todas as Transações
          </CardTitle>
          <CardDescription>
            Histórico completo de movimentações na sua conta
          </CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhuma transação encontrada</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>
                      {new Date(transaction.date).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={transaction.type === 'monthly_result' ? "default" : "destructive"}
                        className="gap-1"
                      >
                        {transaction.type === 'monthly_result' ? (
                          <TrendingUp className="h-3 w-3" />
                        ) : (
                          <TrendingDown className="h-3 w-3" />
                        )}
                        {transaction.type === 'monthly_result' ? 'Retorno' : 'Saque'}
                      </Badge>
                    </TableCell>
                    <TableCell>{transaction.description}</TableCell>
                    <TableCell className="text-right">
                      <span className={transaction.amount >= 0 ? "text-green-600" : "text-red-600"}>
                        {formatCurrency(Math.abs(transaction.amount))}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}