// src/pages/investor/CriptoXPIA.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkBreaks from "remark-breaks";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/lib/supabaseClient";

// ----------------- Tipos e constantes -----------------
type TFValue = "1m" | "5m" | "15m" | "1h" | "4h" | "1d" | "1w";

const TIMEFRAMES: { label: string; value: TFValue }[] = [
  { label: "1 minuto", value: "1m" },
  { label: "5 minutos", value: "5m" },
  { label: "15 minutos", value: "15m" },
  { label: "1 hora", value: "1h" },
  { label: "4 horas", value: "4h" },
  { label: "Diário", value: "1d" },
  { label: "Semanal", value: "1w" },
];

const tvIntervalMap: Record<TFValue, string> = {
  "1m": "1",
  "5m": "5",
  "15m": "15",
  "1h": "60",
  "4h": "240",
  "1d": "D",
  "1w": "W",
};

// Plugins do ReactMarkdown (com cast para evitar TS2322 em stacks desalineadas)
const mdPlugins = [remarkGfm as unknown as any, remarkBreaks as unknown as any];

// --------------- Binance Futures symbols (USDT-M) ---------------
async function fetchUsdtFuturesSymbols(): Promise<string[]> {
  try {
    const r = await fetch("https://fapi.binance.com/fapi/v1/exchangeInfo");
    const j = await r.json();
    const list: string[] = (j.symbols || [])
      .filter((s: any) => s.quoteAsset === "USDT" && s.contractType && s.status === "TRADING")
      .map((s: any) => s.symbol);

    // Ordena priorizando BTC/ETH
    const sorted = Array.from(new Set(list)).sort((a, b) => {
      const w = (x: string) => (x.startsWith("BTC") ? 0 : x.startsWith("ETH") ? 1 : 2);
      const d = w(a) - w(b);
      return d !== 0 ? d : a.localeCompare(b);
    });
    return sorted;
  } catch {
    // Fallback mínimo se a exchangeInfo falhar
    return ["BTCUSDT", "ETHUSDT", "BNBUSDT", "XRPUSDT"];
  }
}

// --------------- TradingView Widget ---------------
function TradingViewChart({ symbol, interval }: { symbol: string; interval: TFValue }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const loaded = useRef(false);

  useEffect(() => {
    if (!containerRef.current) return;

    // Limpa container
    containerRef.current.innerHTML = "";

    const render = () => {
      // Futuros perpétuos da Binance: sufixo .P
      const tvSymbol = `BINANCE:${symbol}.P`;
      const containerId = `tv_${symbol}_${interval}_${Math.random().toString(36).slice(2)}`;

      // Cria um filho com ID estável para o widget
      const child = document.createElement("div");
      child.id = containerId;
      child.style.width = "100%";
      child.style.height = "100%";
      containerRef.current!.appendChild(child);

      // @ts-ignore - TradingView global
      if (typeof TradingView === "undefined") return;
      // @ts-ignore
      new TradingView.widget({
        autosize: true,
        symbol: tvSymbol,
        interval: tvIntervalMap[interval],
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "br",
        toolbar_bg: "#0B0B0F",
        hide_top_toolbar: false,
        hide_legend: false,
        save_image: false,
        container_id: containerId,
      });
    };

    // Carrega o script tv.js uma única vez
    if (!loaded.current) {
      const s = document.createElement("script");
      s.src = "https://s3.tradingview.com/tv.js";
      s.async = true;
      s.onload = () => {
        loaded.current = true;
        render();
      };
      containerRef.current.appendChild(s);
    } else {
      render();
    }
  }, [symbol, interval]);

  return (
    <div
      ref={containerRef}
      className="h-[520px] w-full rounded-xl border bg-card"
      aria-label={`Gráfico ${symbol} ${interval}`}
    />
  );
}

// --------------- Card de Análise por IA ---------------
function AiAnalysisCard({ symbol, interval }: { symbol: string; interval: TFValue }) {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<string>("");
  const [error, setError] = useState<string>("");

  const generate = async () => {
    setLoading(true);
    setError("");
    setAnalysis("");

    try {
      if (!supabase) throw new Error("Supabase não configurado. Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY.");

      // Chama função Edge
      const { data, error } = await supabase.functions.invoke("ai-analysis", {
        body: { symbol, interval, format: "markdown" /*, model: "gpt-5-nano", debug: true*/ },
      });

      if (error) {
        // @ts-ignore
        const ctx = error?.context;
        throw new Error(`Falha ao gerar análise${ctx ? ` — ${JSON.stringify(ctx)}` : ""}`);
      }

      // Normalizador robusto
      const payload = data as any;
      const candidates = [
        payload?.content,                          // nosso backend (Responses API normalizado)
        payload?.output_text,                      // Responses API (campo de conveniência)
        payload?.data?.content,                    // algum wrapper
        payload?.choices?.[0]?.message?.content,   // fallback compat chat
      ];
      const picked = candidates.find((v) => typeof v === "string" && v.trim().length > 0) || "";
      const text = picked.trim();

      if (!text) {
        setError("A resposta veio vazia. Tente novamente em alguns segundos.");
        return;
      }
      if (/R\$|BRL/i.test(text)) {
        setError("A análise retornou valores em BRL. Gere novamente (o servidor força USDT).");
        return;
      }

      setAnalysis(text);
    } catch (e: any) {
      setError(e?.message || "Erro inesperado");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base md:text-lg">Inteligência Artificial CriptoXP</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={generate} disabled={loading} className="w-full sm:w-auto">
          {loading ? "Gerando..." : "Gerar análise e possíveis operações"}
        </Button>

        {error && <div className="text-sm text-red-500">{error}</div>}

        {analysis && (
          <div
            className="
              prose prose-sm md:prose-base dark:prose-invert max-w-none
              prose-headings:font-bold prose-h2:text-xl prose-h3:text-lg
              prose-p:my-3 prose-li:my-1 prose-strong:font-semibold
              prose-a:underline hover:prose-a:opacity-80
              prose-img:rounded-xl
              prose-pre:bg-muted/70 prose-pre:p-3 prose-pre:rounded-lg
              break-words"
          >
            <ReactMarkdown
              remarkPlugins={mdPlugins}
              components={{
                table: ({ node, ...props }) => (
                  <div className="overflow-x-auto my-3">
                    <table className="w-full" {...props} />
                  </div>
                ),
              }}
            >
              {analysis}
            </ReactMarkdown>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// --------------- Página principal ---------------
export default function CriptoXPIA() {
  const [symbols, setSymbols] = useState<string[]>([]);
  const [symbol, setSymbol] = useState<string>("BTCUSDT");
  const [interval, setInterval] = useState<TFValue>("15m");

  // Carrega pares de Futuros USDT-M
  useEffect(() => {
    fetchUsdtFuturesSymbols().then(setSymbols);
  }, []);

  const tfLabel = useMemo(
    () => TIMEFRAMES.find((t) => t.value === interval)?.label ?? "15 minutos",
    [interval]
  );

  return (
    <div className="space-y-6 p-3 md:p-6">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base md:text-lg">CriptoXP IA</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          {/* Select de moeda */}
          <div className="flex flex-col gap-1">
            <label className="text-xs text-muted-foreground">Criptomoeda (Futuros USDT-M)</label>
            <select
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="h-10 rounded-md border bg-background px-3"
            >
              {(symbols.length ? symbols : ["BTCUSDT", "ETHUSDT", "BNBUSDT", "XRPUSDT"]).map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Select de timeframe */}
          <div className="flex flex-col gap-1">
            <label className="text-xs text-muted-foreground">Tempo gráfico</label>
            <select
              value={interval}
              onChange={(e) => setInterval(e.target.value as TFValue)}
              className="h-10 rounded-md border bg-background px-3"
            >
              {TIMEFRAMES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </div>

          {/* Info do par/tempo (opcional) */}
          <div className="hidden md:flex items-end justify-end text-sm text-muted-foreground">
            <span>
              Par: <strong>{symbol}</strong> · Timeframe: <strong>{tfLabel}</strong>
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Gráfico TradingView */}
      <TradingViewChart symbol={symbol} interval={interval} />

      {/* Card da IA */}
      <AiAnalysisCard symbol={symbol} interval={interval} />
    </div>
  );
}
