import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { 
  Briefcase,
  Calendar,
  TrendingUp,
  TrendingDown,
  Loader2,
  FileText
} from 'lucide-react';

interface Operation {
  id: string;
  type: string;
  notes: string;
  image_url: string;
  executed_at: string;
  asset: {
    symbol: string;
    name: string;
    class: string;
  };
}

export default function InvestorOperations() {
  const { user } = useAuth();
  const [allOperations, setAllOperations] = useState<Operation[]>([]);
  const [operations, setOperations] = useState<Operation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState<string>('all');

  useEffect(() => {
    if (user) {
      loadOperations();
    }
  }, [user]);

  useEffect(() => {
    filterOperations();
  }, [selectedMonth, allOperations]);

  const loadOperations = async () => {
    try {
      setLoading(true);

      // Get investor account
      const { data: accounts } = await supabase
        .from('investor_accounts')
        .select('id')
        .eq('investor_id', user?.id)
        .single();

      if (!accounts) {
        setLoading(false);
        return;
      }

      // Load operations with assets
      const { data: operationsData } = await supabase
        .from('operations')
        .select(`
          *,
          assets!inner(symbol, name, class)
        `)
        .eq('account_id', accounts.id)
        .order('executed_at', { ascending: false });

      if (operationsData) {
        const formattedOperations = operationsData.map(op => ({
          id: op.id,
          type: op.type,
          notes: op.notes || '',
          image_url: op.image_url || '',
          executed_at: op.executed_at,
          asset: {
            symbol: op.assets.symbol,
            name: op.assets.name,
            class: op.assets.class
          }
        }));
        
        setAllOperations(formattedOperations);
        setOperations(formattedOperations);
      }

    } catch (error) {
      console.error('Error loading operations:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterOperations = () => {
    if (selectedMonth === 'all') {
      setOperations(allOperations);
    } else {
      const [year, month] = selectedMonth.split('-').map(Number);
      const filtered = allOperations.filter(operation => {
        const operationDate = new Date(operation.executed_at);
        return operationDate.getFullYear() === year && operationDate.getMonth() + 1 === month;
      });
      setOperations(filtered);
    }
  };

  const clearFilters = () => {
    setSelectedMonth('all');
  };

  // Gerar lista de meses disponíveis
  const getAvailableMonths = () => {
    const months = new Set<string>();
    allOperations.forEach(operation => {
      const date = new Date(operation.executed_at);
      const monthKey = `${date.getFullYear()}-${date.getMonth() + 1}`;
      months.add(monthKey);
    });
    
    return Array.from(months)
      .sort((a, b) => {
        const [yearA, monthA] = a.split('-').map(Number);
        const [yearB, monthB] = b.split('-').map(Number);
        return yearB - yearA || monthB - monthA;
      })
      .map(monthKey => {
        const [year, month] = monthKey.split('-').map(Number);
        const monthName = new Date(year, month - 1).toLocaleDateString('pt-BR', { 
          month: 'long', 
          year: 'numeric' 
        });
        return { value: monthKey, label: monthName };
      });
  };


  const formatDate = (dateString: string) => {
    return new Date(dateString + 'T00:00:00').toLocaleDateString('pt-BR');
  };

  const getOperationTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'compra':
      case 'buy':
        return 'default';
      case 'venda':
      case 'sell':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getOperationIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'compra':
      case 'buy':
        return <TrendingUp className="h-4 w-4" />;
      case 'venda':
      case 'sell':
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <Briefcase className="h-4 w-4" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Operações</h1>
        <p className="text-muted-foreground">
          Visualize todas as operações realizadas em sua carteira
        </p>
      </div>

      {/* Filtros */}
      {allOperations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Mês</label>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os meses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os meses</SelectItem>
                    {getAvailableMonths().map((month) => (
                      <SelectItem key={month.value} value={month.value}>
                        {month.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button variant="outline" onClick={clearFilters}>
                  Limpar Filtros
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {operations.length === 0 ? (
        <Card className="card-glass">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Briefcase className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-lg">Nenhuma operação encontrada</p>
            <p className="text-sm text-muted-foreground mt-2">
              As operações realizadas pelo administrador aparecerão aqui
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="card-glass">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Total de Operações</p>
                    <p className="text-2xl font-bold">{operations.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="card-glass">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Compras</p>
                    <p className="text-2xl font-bold text-green-600">
                      {operations.filter(op => op.type.toLowerCase() === 'compra' || op.type.toLowerCase() === 'buy').length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="card-glass">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-red-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Vendas</p>
                    <p className="text-2xl font-bold text-red-600">
                      {operations.filter(op => op.type.toLowerCase() === 'venda' || op.type.toLowerCase() === 'sell').length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Operations Carousel */}
          <Card className="card-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Histórico de Operações
              </CardTitle>
              <CardDescription>
                Navegue pelas operações usando as setas laterais
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Carousel className="w-full">
                <CarouselContent>
                  {operations.map((operation) => (
                    <CarouselItem key={operation.id} className="md:basis-1/2 lg:basis-1/3">
                      <div className="space-y-4">
                        {/* Operation Image */}
                        <div className="aspect-video w-full bg-muted rounded-lg overflow-hidden">
                          {operation.image_url ? (
                            <img
                              src={operation.image_url}
                              alt={`Operação ${operation.asset.symbol}`}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <FileText className="h-12 w-12 text-muted-foreground" />
                            </div>
                          )}
                        </div>

                        {/* Operation Details */}
                        <div className="space-y-3">
                          {/* Asset Info */}
                          <div className="text-center">
                            <h3 className="font-semibold text-lg">{operation.asset.symbol}</h3>
                            <p className="text-sm text-muted-foreground">{operation.asset.name}</p>
                            <Badge variant="outline" className="mt-1">
                              {operation.asset.class}
                            </Badge>
                          </div>

                          {/* Operation Type */}
                          <div className="flex justify-center">
                            <Badge 
                              variant={getOperationTypeColor(operation.type)}
                              className="gap-1"
                            >
                              {getOperationIcon(operation.type)}
                              {operation.type}
                            </Badge>
                          </div>

                          {/* Financial Info - Removed as requested */}
                          
                          {/* Date and Notes */}
                          <div className="space-y-2 text-sm">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDate(operation.executed_at)}</span>
                            </div>
                            {operation.notes && (
                              <div className="p-2 bg-accent/30 rounded text-xs">
                                <strong>Observações:</strong> {operation.notes}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious />
                <CarouselNext />
              </Carousel>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}