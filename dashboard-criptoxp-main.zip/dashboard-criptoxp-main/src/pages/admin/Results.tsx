import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, ArrowLeft, Edit, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

interface MonthlyResult {
  id: string;
  year: number;
  month: number;
  return_amount: number | null;
  return_percent: number;
  comment: string | null;
  account_id: string;
  created_at: string;
  investor_account: {
    display_name: string;
    investor: {
      email: string;
    };
  };
}

interface InvestorAccount {
  id: string;
  display_name: string;
  investor: {
    email: string;
  };
}

const formSchema = z.object({
  year: z.number().min(2020).max(2030),
  month: z.number().min(1).max(12),
  return_amount: z.number().min(0, 'Valor deve ser positivo'),
  return_percent: z.number().min(-100).max(1000),
  comment: z.string().optional(),
});

const months = [
  { value: 1, label: 'Janeiro' },
  { value: 2, label: 'Fevereiro' },
  { value: 3, label: 'Março' },
  { value: 4, label: 'Abril' },
  { value: 5, label: 'Maio' },
  { value: 6, label: 'Junho' },
  { value: 7, label: 'Julho' },
  { value: 8, label: 'Agosto' },
  { value: 9, label: 'Setembro' },
  { value: 10, label: 'Outubro' },
  { value: 11, label: 'Novembro' },
  { value: 12, label: 'Dezembro' },
];

export default function Results() {
  const [results, setResults] = useState<MonthlyResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingResult, setEditingResult] = useState<MonthlyResult | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });

  useEffect(() => {
    loadResults();
  }, []);

  const loadResults = async () => {
    try {
      const { data, error } = await supabase
        .from('monthly_results')
        .select(`
          *,
          investor_account:investor_accounts(
            display_name,
            investor:profiles(email)
          )
        `)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      if (error) throw error;
      setResults(data || []);
    } catch (error) {
      console.error('Error loading results:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar resultados',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number | null) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(2)}%`;
  };

  const getMonthName = (monthNumber: number) => {
    return months.find(m => m.value === monthNumber)?.label || '';
  };

  const handleEdit = (result: MonthlyResult) => {
    setEditingResult(result);
    form.reset({
      year: result.year,
      month: result.month,
      return_amount: Number(result.return_amount) || 0,
      return_percent: Number(result.return_percent),
      comment: result.comment || '',
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = async (values: z.infer<typeof formSchema>) => {
    if (!editingResult) return;

    try {
      const { error } = await supabase
        .from('monthly_results')
        .update({
          year: values.year,
          month: values.month,
          return_amount: values.return_amount,
          return_percent: values.return_percent,
          comment: values.comment || null,
        })
        .eq('id', editingResult.id);

      if (error) throw error;

      toast({
        title: 'Resultado atualizado com sucesso!',
        description: 'As alterações foram salvas.',
      });

      setIsEditDialogOpen(false);
      setEditingResult(null);
      loadResults();
    } catch (error) {
      console.error('Error updating result:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao atualizar resultado',
        variant: 'destructive',
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('monthly_results')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Resultado excluído com sucesso!',
        description: 'O resultado foi removido do sistema.',
      });

      loadResults();
    } catch (error) {
      console.error('Error deleting result:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao excluir resultado',
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center">Carregando resultados...</div>
      </div>
    );
  }

  return (
    <div className="mobile-container space-y-4 lg:space-y-6">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/app/admin')}
            className="gap-2 touch-target"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
          <div>
            <h1 className="text-xl lg:text-2xl font-bold">Resultados Mensais</h1>
            <p className="text-sm lg:text-base text-muted-foreground">
              Visualize todos os resultados cadastrados para os investidores
            </p>
          </div>
        </div>
        <Button 
          onClick={() => navigate('/app/admin/new-result')} 
          className="gap-2 w-full lg:w-auto touch-target"
        >
          <Plus className="h-4 w-4" />
          Novo Resultado
        </Button>
      </div>

      {results.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground">Nenhum resultado encontrado</p>
            <Button
              onClick={() => navigate('/app/admin/new-result')}
              className="mt-4"
            >
              Cadastrar Primeiro Resultado
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {results.map((result) => (
            <Card key={result.id}>
              <CardHeader>
                <div className="space-y-3">
                  <div>
                    <CardTitle className="text-base lg:text-lg">
                      {result.investor_account.display_name}
                    </CardTitle>
                    <CardDescription className="text-sm">
                      {result.investor_account.investor.email}
                    </CardDescription>
                  </div>
                  <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
                    <div className="text-sm">
                      <div className="text-muted-foreground">
                        {getMonthName(result.month)} {result.year}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Criado em {new Date(result.created_at).toLocaleDateString('pt-BR')}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(result)}
                        className="gap-1 touch-target flex-1 lg:flex-none"
                      >
                        <Edit className="h-4 w-4" />
                        Editar
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm" className="gap-1 text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground touch-target flex-1 lg:flex-none">
                            <Trash2 className="h-4 w-4" />
                            Excluir
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja excluir este resultado? Esta ação não pode ser desfeita.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(result.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Excluir
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs lg:text-sm font-medium text-muted-foreground">
                      Retorno Percentual
                    </label>
                    <p className="text-base lg:text-lg font-semibold text-green-600">
                      {formatPercent(result.return_percent)}
                    </p>
                  </div>
                  <div>
                    <label className="text-xs lg:text-sm font-medium text-muted-foreground">
                      Valor do Retorno
                    </label>
                    <p className="text-base lg:text-lg font-semibold">
                      {formatCurrency(result.return_amount)}
                    </p>
                  </div>
                  <div>
                    <label className="text-xs lg:text-sm font-medium text-muted-foreground">
                      Comentário
                    </label>
                    <p className="text-sm break-words">
                      {result.comment || 'Nenhum comentário'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Editar Resultado</DialogTitle>
            <DialogDescription>
              Atualize as informações do resultado mensal
            </DialogDescription>
          </DialogHeader>
          
          {editingResult && (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleUpdate)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ano</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="month"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mês</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione o mês" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {months.map((month) => (
                              <SelectItem key={month.value} value={month.value.toString()}>
                                {month.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="return_amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valor de Retorno (R$)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0,00"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="return_percent"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Percentual de Retorno (%)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0,00"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="comment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Comentário (Opcional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Adicione observações sobre este resultado..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex gap-3 pt-4">
                  <Button type="submit">
                    Atualizar
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsEditDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}