import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Users, 
  TrendingUp, 
  Calendar, 
  Mail, 
  User, 
  Edit, 
  Check, 
  X, 
  Trash2,
  Clock,
  UserCheck,
  UserX,
  Search
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface Investor {
  id: string;
  email: string;
  username: string | null;
  full_name: string | null;
  birth_date: string | null;
  investment_profile: string | null;
  avatar_url: string | null;
  created_at: string;
  account_status: 'pending' | 'approved' | 'rejected';
}

export default function Investors() {
  const [investors, setInvestors] = useState<Investor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [editingInvestor, setEditingInvestor] = useState<Investor | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  // Form states for editing investor
  const [editForm, setEditForm] = useState({
    full_name: '',
    username: '',
    birth_date: '',
    investment_profile: ''
  });

  useEffect(() => {
    fetchInvestors();
    
    // Set up real-time subscription for profile changes
    const subscription = supabase
      .channel('profiles_changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: 'role=eq.investor'
        },
        (payload) => {
          console.log('Profile updated:', payload);
          // Refresh investors list when any investor profile is updated
          fetchInvestors();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchInvestors = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, username, full_name, birth_date, investment_profile, avatar_url, created_at, account_status')
        .eq('role', 'investor')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setInvestors((data || []) as Investor[]);
    } catch (error: any) {
      console.error('Error fetching investors:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os investidores.",
      });
    } finally {
      setLoading(false);
    }
  };

  const getInvestmentProfileBadge = (profile: string | null) => {
    if (!profile) return null;
    
    return (
      <Badge 
        variant={profile === 'conservador' ? 'secondary' : 'default'}
        className={profile === 'conservador' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'}
      >
        <TrendingUp className="w-3 h-3 mr-1" />
        {profile === 'conservador' ? 'Conservador' : 'Agressivo'}
      </Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return (
          <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
            <UserCheck className="w-3 h-3 mr-1" />
            Aprovado
          </Badge>
        );
      case 'pending':
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
            <Clock className="w-3 h-3 mr-1" />
            Pendente
          </Badge>
        );
      case 'rejected':
        return (
          <Badge variant="destructive" className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
            <UserX className="w-3 h-3 mr-1" />
            Rejeitado
          </Badge>
        );
      default:
        return null;
    }
  };

  const handleApproveInvestor = async (investorId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ account_status: 'approved' })
        .eq('id', investorId);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Conta do investidor aprovada com sucesso",
      });

      fetchInvestors();
    } catch (error) {
      console.error('Error approving investor:', error);
      toast({
        title: "Erro",
        description: "Erro ao aprovar conta do investidor",
        variant: "destructive",
      });
    }
  };

  const handleRejectInvestor = async (investorId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ account_status: 'rejected' })
        .eq('id', investorId);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Conta do investidor rejeitada",
      });

      fetchInvestors();
    } catch (error) {
      console.error('Error rejecting investor:', error);
      toast({
        title: "Erro",
        description: "Erro ao rejeitar conta do investidor",
        variant: "destructive",
      });
    }
  };

  const handleDeleteInvestor = async (investorId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', investorId);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Investidor excluído com sucesso",
      });

      fetchInvestors();
    } catch (error) {
      console.error('Error deleting investor:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir investidor",
        variant: "destructive",
      });
    }
  };

  const handleEditInvestor = (investor: Investor) => {
    setEditingInvestor(investor);
    setEditForm({
      full_name: investor.full_name || '',
      username: investor.username || '',
      birth_date: investor.birth_date || '',
      investment_profile: investor.investment_profile || ''
    });
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!editingInvestor) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: editForm.full_name || null,
          username: editForm.username || null,
          birth_date: editForm.birth_date || null,
          investment_profile: editForm.investment_profile || null
        })
        .eq('id', editingInvestor.id);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Dados do investidor atualizados com sucesso",
      });

      setIsEditDialogOpen(false);
      setEditingInvestor(null);
      fetchInvestors();
    } catch (error) {
      console.error('Error updating investor:', error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar dados do investidor",
        variant: "destructive",
      });
    }
  };

  // Filter investors based on search and status
  const filteredInvestors = investors.filter(investor => {
    const matchesSearch = 
      investor.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      investor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      investor.username?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || investor.account_status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Investidores</h1>
            <p className="text-muted-foreground">
              Gerencie informações dos investidores
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="card-glass animate-pulse">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-muted rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-3/4"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Investidores</h1>
          <p className="text-muted-foreground">
            Gerencie informações dos investidores ({filteredInvestors.length} de {investors.length} total)
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Buscar por nome, email ou username..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filtrar por status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="pending">Pendentes</SelectItem>
            <SelectItem value="approved">Aprovados</SelectItem>
            <SelectItem value="rejected">Rejeitados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Investors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInvestors.map((investor) => (
          <Card key={investor.id} className="card-glass hover:shadow-lg transition-shadow">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between space-x-4">
                <div className="flex items-start space-x-4 flex-1 min-w-0">
                  <Avatar className="w-12 h-12">
                    <AvatarImage 
                      src={investor.avatar_url || ''} 
                      alt={investor.full_name || investor.email}
                    />
                    <AvatarFallback className="text-sm">
                      {investor.full_name?.charAt(0) || investor.email?.charAt(0)?.toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate">
                      {investor.full_name || investor.username || 'Sem nome'}
                    </CardTitle>
                    <CardDescription className="truncate">
                      {investor.email}
                    </CardDescription>
                  </div>
                </div>
                
                {/* Status Badge */}
                <div className="flex-shrink-0">
                  {getStatusBadge(investor.account_status)}
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Email */}
              <div className="flex items-center text-sm text-muted-foreground">
                <Mail className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">{investor.email}</span>
              </div>

              {/* Full Name */}
              {investor.full_name && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <User className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">{investor.full_name}</span>
                </div>
              )}

              {/* Birth Date */}
              {investor.birth_date && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span>{format(new Date(investor.birth_date + 'T00:00:00'), 'dd/MM/yyyy', { locale: ptBR })}</span>
                </div>
              )}

              {/* Investment Profile */}
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Perfil:</span>
                {getInvestmentProfileBadge(investor.investment_profile) || (
                  <Badge variant="outline" className="text-xs">
                    Não definido
                  </Badge>
                )}
              </div>

              {/* Member Since */}
              <div className="flex items-center text-xs text-muted-foreground pt-2 border-t">
                <Users className="w-3 h-3 mr-2" />
                <span>
                  Membro desde {format(new Date(investor.created_at), 'MMM yyyy', { locale: ptBR })}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-2 border-t">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEditInvestor(investor)}
                  className="flex-1"
                >
                  <Edit className="w-3 h-3 mr-1" />
                  Editar
                </Button>
                
                {investor.account_status === 'pending' && (
                  <>
                    <Button
                      size="sm"
                      onClick={() => handleApproveInvestor(investor.id)}
                      className="bg-green-600 hover:bg-green-700 text-white flex-1"
                    >
                      <Check className="w-3 h-3 mr-1" />
                      Aprovar
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleRejectInvestor(investor.id)}
                      className="flex-1"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Rejeitar
                    </Button>
                  </>
                )}
                
                {investor.account_status === 'rejected' && (
                  <Button
                    size="sm"
                    onClick={() => handleApproveInvestor(investor.id)}
                    className="bg-green-600 hover:bg-green-700 text-white flex-1"
                  >
                    <Check className="w-3 h-3 mr-1" />
                    Aprovar
                  </Button>
                )}
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="destructive" className="w-full mt-2">
                      <Trash2 className="w-3 h-3 mr-1" />
                      Excluir
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                      <AlertDialogDescription>
                        Tem certeza que deseja excluir permanentemente o investidor {investor.full_name || investor.email}? 
                        Esta ação não pode ser desfeita.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={() => handleDeleteInvestor(investor.id)}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        Excluir
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredInvestors.length === 0 && (
        <Card className="card-glass">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">
              {investors.length === 0 ? 'Nenhum investidor encontrado' : 'Nenhum resultado encontrado'}
            </h3>
            <p className="text-muted-foreground text-center max-w-md">
              {investors.length === 0 
                ? 'Não há investidores cadastrados no sistema no momento.'
                : 'Tente ajustar os filtros de busca para encontrar o que procura.'
              }
            </p>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Editar Investidor</DialogTitle>
            <DialogDescription>
              Faça alterações nos dados do investidor aqui. Clique em salvar quando terminar.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="full_name">Nome Completo</Label>
              <Input
                id="full_name"
                value={editForm.full_name}
                onChange={(e) => setEditForm(prev => ({ ...prev, full_name: e.target.value }))}
                placeholder="Nome completo"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={editForm.username}
                onChange={(e) => setEditForm(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Username"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="birth_date">Data de Nascimento</Label>
              <Input
                id="birth_date"
                type="date"
                value={editForm.birth_date}
                onChange={(e) => setEditForm(prev => ({ ...prev, birth_date: e.target.value }))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="investment_profile">Perfil de Investimento</Label>
              <Select 
                value={editForm.investment_profile} 
                onValueChange={(value) => setEditForm(prev => ({ ...prev, investment_profile: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o perfil" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="conservador">Conservador</SelectItem>
                  <SelectItem value="agressivo">Agressivo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" onClick={handleSaveEdit}>
              Salvar alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}