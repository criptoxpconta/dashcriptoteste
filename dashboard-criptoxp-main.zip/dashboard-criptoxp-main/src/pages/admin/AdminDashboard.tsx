import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  Activity,
  Eye,
  Edit,
  Plus,
  PieChart
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { QuoteCard } from '@/components/quotes/QuoteCard';
import { fetchQuote } from '@/api/quotes';

interface InvestorSummary {
  id: string;
  email: string;
  display_name: string;
  current_balance: number;
  monthly_return: number;
  account_id: string;
  assets_symbols: string[];
  total_invested: number;
  total_returns: number;
  total_withdrawals: number;
}

export default function AdminDashboard() {
  const [investors, setInvestors] = useState<InvestorSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalInvestors: 0,
    totalAUM: 0,
    avgReturn: 0,
    activeAccounts: 0
  });
  const navigate = useNavigate();

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      setLoading(true);

      // Load investors with their accounts and latest balance
      const { data: investorData } = await supabase
        .from('profiles')
        .select(`
          id,
          email,
          investor_accounts!inner (
            id,
            display_name
          )
        `)
        .eq('role', 'investor');

      if (!investorData) {
        setLoading(false);
        return;
      }

      // For each investor, get their current balance and monthly return
      const investorSummaries: InvestorSummary[] = [];
      let totalAUM = 0;
      let totalReturns = 0;
      let returnCount = 0;

      for (const investor of investorData) {
        const accountId = investor.investor_accounts[0]?.id;
        
        if (accountId) {
          // Get actual invested amount from investment_amounts table
          const { data: investmentData } = await supabase
            .from('investment_amounts')
            .select('total_invested')
            .eq('account_id', accountId)
            .maybeSingle();
          
          const totalInvested = investmentData?.total_invested || 0;

          // Get total withdrawals
          const { data: withdrawalsData } = await supabase
            .from('withdrawals')
            .select('amount')
            .eq('account_id', accountId);
          
          const totalWithdrawals = withdrawalsData?.reduce((sum, withdrawal) => sum + Number(withdrawal.amount), 0) || 0;

          // Get all monthly results amounts (sum all months, not just last one)
          const { data: allResultsData } = await supabase
            .from('monthly_results')
            .select('return_amount')
            .eq('account_id', accountId);
          
          const totalReturnsAmount = allResultsData?.reduce((sum, result) => sum + (Number(result.return_amount) || 0), 0) || 0;

          // Get positions to calculate assets value and collect symbols
          const { data: positionsData } = await supabase
            .from('positions')
            .select(`
              quantity,
              assets!inner(symbol)
            `)
            .eq('account_id', accountId);

          // Calculate current value of assets based on live quotes and collect symbols
          let assetsValue = 0;
          const assetsSymbols: string[] = [];
          
          if (positionsData && positionsData.length > 0) {
            for (const position of positionsData) {
              const assetSymbol = position.assets?.symbol;
              if (assetSymbol) {
                assetsSymbols.push(assetSymbol);
                
                let price = 0;
                if (assetSymbol === 'BTC') {
                  const response = await fetchQuote('btcbrl');
                  if (response.success && response.data) {
                    price = response.data.price;
                  }
                } else if (assetSymbol === 'USDT' || assetSymbol === 'USD') {
                  const response = await fetchQuote('usdbrl');
                  if (response.success && response.data) {
                    price = response.data.price;
                  }
                }
                
                assetsValue += position.quantity * price;
              }
            }
          }

          // Calculate current balance: Valor dos ativos + Retornos - Saques
          const currentBalance = assetsValue + totalReturnsAmount - totalWithdrawals;

          // Get latest monthly return for display
          const { data: latestReturn } = await supabase
            .from('monthly_results')
            .select('return_percent')
            .eq('account_id', accountId)
            .order('year', { ascending: false })
            .order('month', { ascending: false })
            .limit(1)
            .maybeSingle();

          const monthlyReturn = latestReturn?.return_percent || 0;

          investorSummaries.push({
            id: investor.id,
            email: investor.email,
            display_name: investor.investor_accounts[0]?.display_name || 'Conta Principal',
            current_balance: currentBalance,
            monthly_return: monthlyReturn,
            account_id: accountId,
            assets_symbols: assetsSymbols,
            total_invested: totalInvested,
            total_returns: totalReturnsAmount,
            total_withdrawals: totalWithdrawals
          });

          totalAUM += currentBalance;
          if (latestReturn) {
            totalReturns += monthlyReturn;
            returnCount++;
          }
        }
      }

      setInvestors(investorSummaries);
      setStats({
        totalInvestors: investorData.length,
        totalAUM,
        avgReturn: returnCount > 0 ? totalReturns / returnCount : 0,
        activeAccounts: investorSummaries.filter(inv => inv.current_balance > 0).length
      });

    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* Quote Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <QuoteCard title="Dólar (USD/BRL)" endpoint="usdbrl" />
        <QuoteCard title="Bitcoin (BTC/BRL)" endpoint="btcbrl" />
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="card-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Investidores</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalInvestors}</div>
            <p className="text-xs text-muted-foreground">
              {stats.activeAccounts} contas ativas
            </p>
          </CardContent>
        </Card>

        <Card className="card-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">AUM Total</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalAUM)}</div>
            <p className="text-xs text-muted-foreground">
              Assets Under Management
            </p>
          </CardContent>
        </Card>

        <Card className="card-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Retorno Médio</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              <span className={stats.avgReturn >= 0 ? 'text-profit' : 'text-loss'}>
                {formatPercent(stats.avgReturn)}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Último mês
            </p>
          </CardContent>
        </Card>

        <Card className="card-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contas Ativas</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeAccounts}</div>
            <p className="text-xs text-muted-foreground">
              Com saldo positivo
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Investors Table */}
      <Card className="card-glass">
        <CardHeader>
          <CardTitle>Investidores</CardTitle>
          <CardDescription>
            Lista de todos os investidores e suas contas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {investors.map((investor) => (
              <div
                key={investor.id}
                className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-sm font-medium text-primary">
                      {investor.email.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{investor.email}</p>
                    <p className="text-sm text-muted-foreground">{investor.display_name}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-6">
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(investor.current_balance)}</p>
                    <p className="text-sm text-muted-foreground">Saldo atual</p>
                  </div>

                  <div className="text-right">
                    <Badge 
                      variant={investor.monthly_return >= 0 ? "default" : "destructive"}
                      className="text-xs"
                    >
                      {formatPercent(investor.monthly_return)}
                    </Badge>
                    <p className="text-sm text-muted-foreground">Último mês</p>
                  </div>

                  <div className="text-right">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Ativos</p>
                      <div className="flex flex-wrap gap-1">
                        {investor.assets_symbols.length > 0 ? (
                          investor.assets_symbols.map((symbol, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {symbol}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-xs text-muted-foreground">Nenhum ativo</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {investors.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Nenhum investidor encontrado</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}