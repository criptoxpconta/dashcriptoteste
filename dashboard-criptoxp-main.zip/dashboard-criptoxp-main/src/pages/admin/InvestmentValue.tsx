import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { 
  DollarSign, 
  User,
  Save,
  Search
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';

interface Investor {
  id: string;
  email: string;
  display_name: string;
  account_id: string;
  current_investment?: number;
}

export default function InvestmentValue() {
  const [investors, setInvestors] = useState<Investor[]>([]);
  const [selectedInvestor, setSelectedInvestor] = useState<string>('');
  const [investmentValue, setInvestmentValue] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    loadInvestors();
  }, []);

  useEffect(() => {
    if (selectedInvestor) {
      loadCurrentInvestment();
    }
  }, [selectedInvestor]);

  const loadInvestors = async () => {
    try {
      setLoading(true);

      // Load investors with their accounts
      const { data: investorData } = await supabase
        .from('profiles')
        .select(`
          id,
          email,
          investor_accounts!inner (
            id,
            display_name
          )
        `)
        .eq('role', 'investor');

      const investorList: Investor[] = investorData?.map(inv => ({
        id: inv.id,
        email: inv.email,
        display_name: inv.investor_accounts[0]?.display_name || 'Conta Principal',
        account_id: inv.investor_accounts[0]?.id
      })) || [];

      setInvestors(investorList);
    } catch (error) {
      console.error('Error loading investors:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar investidores",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadCurrentInvestment = async () => {
    if (!selectedInvestor) return;

    try {
      const investor = investors.find(inv => inv.id === selectedInvestor);
      if (!investor) return;

      const { data: investmentData } = await supabase
        .from('investment_amounts')
        .select('total_invested')
        .eq('account_id', investor.account_id)
        .maybeSingle();

      if (investmentData) {
        setInvestmentValue(investmentData.total_invested.toString());
      } else {
        setInvestmentValue('0');
      }
    } catch (error) {
      console.error('Error loading current investment:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar valor atual do investimento",
        variant: "destructive",
      });
    }
  };

  const handleSaveInvestment = async () => {
    if (!selectedInvestor || !investmentValue || !user) {
      toast({
        title: "Erro",
        description: "Selecione um investidor e preencha o valor",
        variant: "destructive",
      });
      return;
    }

    try {
      setSaving(true);
      const investor = investors.find(inv => inv.id === selectedInvestor);
      if (!investor) return;

      const value = parseFloat(investmentValue.replace(/[^0-9.,]/g, '').replace(',', '.'));
      
      if (isNaN(value) || value < 0) {
        toast({
          title: "Erro",
          description: "Digite um valor válido",
          variant: "destructive",
        });
        return;
      }

      // Check if record exists
      const { data: existingRecord } = await supabase
        .from('investment_amounts')
        .select('id')
        .eq('account_id', investor.account_id)
        .maybeSingle();

      if (existingRecord) {
        // Update existing record
        const { error } = await supabase
          .from('investment_amounts')
          .update({
            total_invested: value,
            updated_at: new Date().toISOString()
          })
          .eq('account_id', investor.account_id);

        if (error) throw error;
      } else {
        // Create new record
        const { error } = await supabase
          .from('investment_amounts')
          .insert({
            account_id: investor.account_id,
            total_invested: value,
            created_by: user.id
          });

        if (error) throw error;
      }

      toast({
        title: "Sucesso",
        description: "Valor do investimento atualizado com sucesso",
      });

    } catch (error) {
      console.error('Error saving investment:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar valor do investimento",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (value: string) => {
    // Remove non-numeric characters except comma and dot
    const numericValue = value.replace(/[^0-9.,]/g, '');
    
    // Convert to number for formatting
    const number = parseFloat(numericValue.replace(',', '.'));
    
    if (isNaN(number)) return '';
    
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(number);
  };

  const handleValueChange = (value: string) => {
    // Only allow numbers, comma, and dot
    const filtered = value.replace(/[^0-9.,]/g, '');
    setInvestmentValue(filtered);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Valor do Investimento</h1>
        <p className="text-muted-foreground">
          Configure o valor total investido por cada investidor
        </p>
      </div>

      {/* Main Form */}
      <Card className="card-glass max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Definir Valor do Investimento
          </CardTitle>
          <CardDescription>
            Selecione um investidor e defina o valor total que ele investiu
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Investor Selection */}
          <div className="space-y-2">
            <Label>Investidor</Label>
            <Select value={selectedInvestor} onValueChange={setSelectedInvestor}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um investidor..." />
              </SelectTrigger>
              <SelectContent>
                {investors.map((investor) => (
                  <SelectItem key={investor.id} value={investor.id}>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      <span>{investor.email} - {investor.display_name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Investment Value */}
          {selectedInvestor && (
            <>
              <div className="space-y-2">
                <Label htmlFor="investment-value">Valor Total Investido (R$)</Label>
                <Input
                  id="investment-value"
                  type="text"
                  placeholder="0,00"
                  value={investmentValue}
                  onChange={(e) => handleValueChange(e.target.value)}
                  className="text-lg"
                />
                {investmentValue && (
                  <p className="text-sm text-muted-foreground">
                    Formatado: {formatCurrency(investmentValue)}
                  </p>
                )}
              </div>

              <Button 
                onClick={handleSaveInvestment} 
                disabled={saving || !investmentValue}
                className="w-full"
              >
                <Save className="h-4 w-4 mr-2" />
                {saving ? 'Salvando...' : 'Salvar Valor do Investimento'}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* Current Investments Summary */}
      <Card className="card-glass">
        <CardHeader>
          <CardTitle>Resumo dos Investimentos</CardTitle>
          <CardDescription>
            Valores atualmente cadastrados para cada investidor
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {investors.map((investor) => (
              <InvestorInvestmentCard key={investor.id} investor={investor} />
            ))}
            
            {investors.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Nenhum investidor encontrado</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Component to show individual investor investment
function InvestorInvestmentCard({ investor }: { investor: Investor }) {
  const [currentInvestment, setCurrentInvestment] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInvestmentValue();
  }, [investor.account_id]);

  const loadInvestmentValue = async () => {
    try {
      const { data } = await supabase
        .from('investment_amounts')
        .select('total_invested')
        .eq('account_id', investor.account_id)
        .maybeSingle();

      setCurrentInvestment(data?.total_invested || 0);
    } catch (error) {
      console.error('Error loading investment value:', error);
      setCurrentInvestment(0);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors">
      <div className="flex items-center space-x-4">
        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
          <span className="text-sm font-medium text-primary">
            {investor.email.charAt(0).toUpperCase()}
          </span>
        </div>
        <div>
          <p className="font-medium">{investor.email}</p>
          <p className="text-sm text-muted-foreground">{investor.display_name}</p>
        </div>
      </div>

      <div className="text-right">
        {loading ? (
          <div className="animate-pulse bg-muted h-6 w-24 rounded"></div>
        ) : (
          <>
            <p className="font-medium text-lg">
              {formatCurrency(currentInvestment || 0)}
            </p>
            <p className="text-sm text-muted-foreground">
              {currentInvestment === 0 ? 'Não definido' : 'Total investido'}
            </p>
          </>
        )}
      </div>
    </div>
  );
}