import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Loader2 } from 'lucide-react';

interface Transaction {
  id: string;
  type: 'return' | 'withdrawal';
  date: string;
  amount: number;
  description: string;
  account_id: string;
  investor_name: string;
}

interface InvestorAccount {
  id: string;
  display_name: string;
  investor_id: string;
}

export default function AdminTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [investors, setInvestors] = useState<InvestorAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvestor, setSelectedInvestor] = useState<string>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => {
    loadInvestors();
    loadTransactions();
  }, []);

  useEffect(() => {
    loadTransactions();
  }, [selectedInvestor, startDate, endDate]);

  const loadInvestors = async () => {
    try {
      const { data: investorAccounts, error } = await supabase
        .from('investor_accounts')
        .select('*')
        .order('display_name');

      if (error) throw error;
      setInvestors(investorAccounts || []);
    } catch (error) {
      console.error('Erro ao carregar investidores:', error);
    }
  };

  const loadTransactions = async () => {
    setLoading(true);
    try {
      // Buscar retornos mensais
      let monthlyQuery = supabase
        .from('monthly_results')
        .select(`
          id,
          account_id,
          year,
          month,
          return_amount,
          created_at,
          investor_accounts!inner(display_name)
        `)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      // Aplicar filtro por investidor
      if (selectedInvestor !== 'all') {
        monthlyQuery = monthlyQuery.eq('account_id', selectedInvestor);
      }

      const { data: monthlyResults, error: monthlyError } = await monthlyQuery;
      if (monthlyError) throw monthlyError;

      // Buscar saques - usando LEFT JOIN manual devido à falta de foreign key
      let withdrawalsQuery = supabase
        .from('withdrawals')
        .select(`
          id,
          account_id,
          amount,
          year,
          month,
          notes,
          created_at
        `)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      // Aplicar filtro por investidor
      if (selectedInvestor !== 'all') {
        withdrawalsQuery = withdrawalsQuery.eq('account_id', selectedInvestor);
      }

      const { data: withdrawalsData, error: withdrawalsError } = await withdrawalsQuery;
      
      // Buscar nomes dos investidores para os saques
      const accountIds = withdrawalsData?.map(w => w.account_id) || [];
      const { data: accountsData } = await supabase
        .from('investor_accounts')
        .select('id, display_name')
        .in('id', accountIds);
      if (withdrawalsError) throw withdrawalsError;

      // Combinar e formatar transações
      const combinedTransactions: Transaction[] = [];

      // Adicionar retornos mensais
      if (monthlyResults) {
        monthlyResults.forEach((result: any) => {
          if (result.return_amount && result.return_amount > 0) {
            const transactionDate = new Date(result.year, result.month - 1, 1);
            
            // Aplicar filtro de data
            if (startDate && transactionDate < new Date(startDate)) return;
            if (endDate && transactionDate > new Date(endDate)) return;

            combinedTransactions.push({
              id: result.id,
              type: 'return',
              date: transactionDate.toISOString().split('T')[0],
              amount: result.return_amount,
              description: `Retorno ${result.month.toString().padStart(2, '0')}/${result.year}`,
              account_id: result.account_id,
              investor_name: result.investor_accounts.display_name
            });
          }
        });
      }

      // Adicionar saques
      if (withdrawalsData && accountsData) {
        withdrawalsData.forEach((withdrawal: any) => {
          const transactionDate = new Date(withdrawal.year, withdrawal.month - 1, 1);
          
          // Aplicar filtro de data
          if (startDate && transactionDate < new Date(startDate)) return;
          if (endDate && transactionDate > new Date(endDate)) return;

          // Encontrar o nome do investidor
          const accountInfo = accountsData.find(acc => acc.id === withdrawal.account_id);
          
          combinedTransactions.push({
            id: withdrawal.id,
            type: 'withdrawal',
            date: transactionDate.toISOString().split('T')[0],
            amount: withdrawal.amount,
            description: `Saque ${withdrawal.month.toString().padStart(2, '0')}/${withdrawal.year}${withdrawal.notes ? ` - ${withdrawal.notes}` : ''}`,
            account_id: withdrawal.account_id,
            investor_name: accountInfo?.display_name || 'Desconhecido'
          });
        });
      }

      // Ordenar por data (mais recente primeiro)
      combinedTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      setTransactions(combinedTransactions);
    } catch (error) {
      console.error('Erro ao carregar transações:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString + 'T00:00:00').toLocaleDateString('pt-BR');
  };

  const clearFilters = () => {
    setSelectedInvestor('all');
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="mobile-container space-y-4 lg:space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl lg:text-3xl font-bold tracking-tight">Transações</h1>
          <p className="text-sm lg:text-base text-muted-foreground">
            Visualize todas as transações dos investidores
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg lg:text-xl">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Investidor</label>
                <Select value={selectedInvestor} onValueChange={setSelectedInvestor}>
                  <SelectTrigger className="touch-target">
                    <SelectValue placeholder="Todos os investidores" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os investidores</SelectItem>
                    {investors.map((investor) => (
                      <SelectItem key={investor.id} value={investor.id}>
                        {investor.display_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Data início</label>
                <Input 
                  type="date" 
                  value={startDate} 
                  onChange={(e) => setStartDate(e.target.value)}
                  className="touch-target"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Data fim</label>
                <Input 
                  type="date" 
                  value={endDate} 
                  onChange={(e) => setEndDate(e.target.value)}
                  className="touch-target"
                />
              </div>
            </div>

            <Button variant="outline" onClick={clearFilters} className="w-full lg:w-auto touch-target">
              Limpar Filtros
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg lg:text-xl">Histórico de Transações</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhuma transação encontrada</p>
            </div>
          ) : (
            <>
              {/* Mobile view */}
              <div className="block lg:hidden space-y-4">
                {transactions.map((transaction) => (
                  <Card key={transaction.id} className="border-l-4 border-l-primary">
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium text-sm">{transaction.investor_name}</p>
                            <p className="text-xs text-muted-foreground">{formatDate(transaction.date)}</p>
                          </div>
                          <Badge 
                            variant={transaction.type === 'return' ? 'default' : 'destructive'}
                            className="text-xs"
                          >
                            {transaction.type === 'return' ? 'Retorno' : 'Saque'}
                          </Badge>
                        </div>
                        <p className="text-sm break-words">{transaction.description}</p>
                        <p className={`text-lg font-bold ${
                          transaction.type === 'return' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {transaction.type === 'return' ? '+' : '-'}{formatCurrency(transaction.amount)}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Desktop view */}
              <div className="hidden lg:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Investidor</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{formatDate(transaction.date)}</TableCell>
                        <TableCell>{transaction.investor_name}</TableCell>
                        <TableCell>
                          <Badge 
                            variant={transaction.type === 'return' ? 'default' : 'destructive'}
                          >
                            {transaction.type === 'return' ? 'Retorno' : 'Saque'}
                          </Badge>
                        </TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell className={`text-right font-mono ${
                          transaction.type === 'return' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {transaction.type === 'return' ? '+' : '-'}{formatCurrency(transaction.amount)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}