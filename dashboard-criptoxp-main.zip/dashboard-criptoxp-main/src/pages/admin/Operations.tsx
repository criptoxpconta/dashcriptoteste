import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, ArrowLeft, Calendar, DollarSign, TrendingUp, FileText, Trash2, Edit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface Operation {
  id: string;
  type: string;
  quantity: number | null;
  price: number | null;
  fee: number | null;
  executed_at: string;
  notes: string | null;
  image_url: string | null;
  investor_account: {
    display_name: string;
    investor: {
      email: string;
    };
  };
  asset: {
    name: string;
    symbol: string;
  } | null;
}

export default function Operations() {
  const [allOperations, setAllOperations] = useState<Operation[]>([]);
  const [operations, setOperations] = useState<Operation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadOperations();
  }, []);

  useEffect(() => {
    filterOperations();
  }, [selectedMonth, allOperations]);

  const loadOperations = async () => {
    try {
      const { data, error } = await supabase
        .from('operations')
        .select(`
          *,
          investor_account:investor_accounts(
            display_name,
            investor:profiles(email)
          ),
          asset:assets(name, symbol)
        `)
        .order('executed_at', { ascending: false });

      if (error) throw error;
      setAllOperations(data || []);
      setOperations(data || []);
    } catch (error) {
      console.error('Error loading operations:', error);
      toast({
        title: 'Erro',
        description: 'Erro ao carregar operações',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterOperations = () => {
    if (selectedMonth === 'all') {
      setOperations(allOperations);
    } else {
      const [year, month] = selectedMonth.split('-').map(Number);
      const filtered = allOperations.filter(operation => {
        const operationDate = new Date(operation.executed_at);
        return operationDate.getFullYear() === year && operationDate.getMonth() + 1 === month;
      });
      setOperations(filtered);
    }
  };

  const formatCurrency = (value: number | null) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatQuantity = (value: number | null) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
    }).format(value);
  };

  const getOperationTypeLabel = (type: string) => {
    const types: { [key: string]: string } = {
      'buy': 'Compra',
      'sell': 'Venda',
      'dividend': 'Dividendo',
      'interest': 'Juros',
      'deposit': 'Depósito',
      'withdrawal': 'Saque',
    };
    return types[type] || type;
  };

  const getOperationTypeColor = (type: string) => {
    const colors: { [key: string]: string } = {
      'buy': 'text-green-600',
      'sell': 'text-red-600',
      'dividend': 'text-blue-600',
      'interest': 'text-purple-600',
      'deposit': 'text-emerald-600',
      'withdrawal': 'text-orange-600',
    };
    return colors[type] || 'text-gray-600';
  };

  
  const clearFilters = () => {
    setSelectedMonth('all');
  };

  const deleteOperation = async (operationId: string) => {
    try {
      const { error } = await supabase
        .from('operations')
        .delete()
        .eq('id', operationId);

      if (error) throw error;

      toast({
        title: 'Operação excluída',
        description: 'A operação foi excluída com sucesso.',
      });

      // Refresh the operations list
      loadOperations();
    } catch (error) {
      console.error('Error deleting operation:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível excluir a operação.',
        variant: 'destructive',
      });
    }
  };

  // Gerar lista de meses disponíveis
  const getAvailableMonths = () => {
    const months = new Set<string>();
    allOperations.forEach(operation => {
      const date = new Date(operation.executed_at);
      const monthKey = `${date.getFullYear()}-${date.getMonth() + 1}`;
      months.add(monthKey);
    });
    
    return Array.from(months)
      .sort((a, b) => {
        const [yearA, monthA] = a.split('-').map(Number);
        const [yearB, monthB] = b.split('-').map(Number);
        return yearB - yearA || monthB - monthA;
      })
      .map(monthKey => {
        const [year, month] = monthKey.split('-').map(Number);
        const monthName = new Date(year, month - 1).toLocaleDateString('pt-BR', { 
          month: 'long', 
          year: 'numeric' 
        });
        return { value: monthKey, label: monthName };
      });
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center">Carregando operações...</div>
      </div>
    );
  }

  return (
    <div className="mobile-container space-y-4 lg:space-y-6">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/app/admin')}
            className="gap-2 touch-target"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
          <div>
            <h1 className="text-xl lg:text-2xl font-bold">Operações</h1>
            <p className="text-sm lg:text-base text-muted-foreground">
              Visualize todas as operações realizadas
            </p>
          </div>
        </div>
        <Button 
          onClick={() => navigate('/app/admin/new-operation')} 
          className="gap-2 w-full lg:w-auto touch-target"
        >
          <Plus className="h-4 w-4" />
          Nova Operação
        </Button>
      </div>

      {/* Filtros */}
      {allOperations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end">
              <div className="space-y-2 flex-1">
                <label className="text-sm font-medium">Mês</label>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os meses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os meses</SelectItem>
                    {getAvailableMonths().map((month) => (
                      <SelectItem key={month.value} value={month.value}>
                        {month.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button variant="outline" onClick={clearFilters} className="touch-target">
                Limpar Filtros
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de Operações */}
      {operations.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground">
              {allOperations.length === 0 ? 'Nenhuma operação encontrada' : 'Nenhuma operação encontrada para o período selecionado'}
            </p>
            {allOperations.length === 0 && (
              <Button
                onClick={() => navigate('/app/admin/new-operation')}
                className="mt-4"
              >
                Cadastrar Primeira Operação
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {operations.map((operation) => (
            <Card key={operation.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="flex flex-col lg:flex-row gap-0">
                  {/* Imagem */}
                  <div className="w-full h-48 lg:w-32 lg:h-32 flex-shrink-0">
                    {operation.image_url ? (
                      <img
                        src={operation.image_url}
                        alt="Comprovante da operação"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-muted flex items-center justify-center">
                        <FileText className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                  </div>

                  {/* Informações */}
                  <div className="flex-1 p-4 lg:p-6">
                    <div className="flex flex-col gap-3 lg:flex-row lg:justify-between lg:items-start mb-4">
                      <div>
                        <h3 className="text-base lg:text-lg font-semibold">
                          {operation.investor_account.display_name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {operation.investor_account.investor.email}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant={
                            operation.type === 'buy' ? 'default' : 
                            operation.type === 'sell' ? 'destructive' : 'secondary'
                          }
                          className="gap-1"
                        >
                          <TrendingUp className="h-3 w-3" />
                          {getOperationTypeLabel(operation.type)}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/app/admin/edit-operation/${operation.id}`)}
                            className="text-primary hover:text-primary hover:bg-primary/10 p-2 h-8 w-8"
                            title="Editar operação"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteOperation(operation.id)}
                            className="text-destructive hover:text-destructive hover:bg-destructive/10 p-2 h-8 w-8"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="space-y-1">
                        <label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Data
                        </label>
                        <p className="text-sm font-medium">
                          {new Date(operation.executed_at + 'T00:00:00').toLocaleDateString('pt-BR')}
                        </p>
                      </div>

                      {operation.asset && (
                        <div className="space-y-1">
                          <label className="text-xs font-medium text-muted-foreground">
                            Ativo
                          </label>
                          <p className="text-sm font-medium break-words">
                            {operation.asset.name} ({operation.asset.symbol})
                          </p>
                        </div>
                      )}

                      {operation.quantity && (
                        <div className="space-y-1">
                          <label className="text-xs font-medium text-muted-foreground">
                            Quantidade
                          </label>
                          <p className="text-sm font-medium">
                            {formatQuantity(operation.quantity)}
                          </p>
                        </div>
                      )}

                      {operation.price && (
                        <div className="space-y-1">
                          <label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                            <DollarSign className="h-3 w-3" />
                            Preço
                          </label>
                          <p className="text-sm font-medium">
                            {formatCurrency(operation.price)}
                          </p>
                        </div>
                      )}
                    </div>

                    {(operation.fee || operation.notes) && (
                      <div className="grid grid-cols-1 gap-4">
                        {operation.fee && (
                          <div className="space-y-1">
                            <label className="text-xs font-medium text-muted-foreground">
                              Taxa
                            </label>
                            <p className="text-sm font-medium">
                              {formatCurrency(operation.fee)}
                            </p>
                          </div>
                        )}

                        {operation.notes && (
                          <div className="space-y-1">
                            <label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                              <FileText className="h-3 w-3" />
                              Observações
                            </label>
                            <p className="text-sm text-muted-foreground break-words">
                              {operation.notes}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          <div className="text-center mt-4">
            <p className="text-sm text-muted-foreground">
              {operations.length} operação(ões) {selectedMonth !== 'all' ? 'no período selecionado' : 'encontrada(s)'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}