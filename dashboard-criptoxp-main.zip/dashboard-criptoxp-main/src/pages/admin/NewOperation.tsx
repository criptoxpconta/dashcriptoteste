import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, TrendingUp, Upload, Image, Users } from 'lucide-react';

const formSchema = z.object({
  account_ids: z.array(z.string()).min(1, 'Selecione pelo menos um investidor'),
  type: z.string().min(1, 'Selecione o tipo de operação'),
  asset_id: z.string().optional(),
  notes: z.string().optional(),
  executed_at: z.string().min(1, 'Data é obrigatória'),
  image: z.any().optional(),
});

interface InvestorAccount {
  id: string;
  display_name: string;
  investor: {
    email: string;
  };
}

interface Asset {
  id: string;
  name: string;
  symbol: string;
}

export default function NewOperation() {
  const [loading, setLoading] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [accounts, setAccounts] = useState<InvestorAccount[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { id: operationId } = useParams();
  const isEditing = !!operationId;

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      account_ids: [],
      type: '',
      executed_at: new Date().toISOString().split('T')[0],
      notes: '',
    },
  });

  useEffect(() => {
    loadInvestorAccounts();
    loadAssets();
    if (isEditing && operationId) {
      loadOperationData(operationId);
    }
  }, [isEditing, operationId]);

  const loadInvestorAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('investor_accounts')
        .select(`
          id,
          display_name,
          profiles!investor_accounts_investor_id_fkey (
            email
          )
        `);

      if (error) throw error;
      
      const transformedData = data?.map(account => ({
        id: account.id,
        display_name: account.display_name,
        investor: {
          email: account.profiles?.email || 'N/A'
        }
      })) || [];

      setAccounts(transformedData);
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
  };

  const loadAssets = async () => {
    try {
      const { data, error } = await supabase
        .from('assets')
        .select('id, name, symbol')
        .order('name');

      if (error) throw error;
      setAssets(data || []);
    } catch (error) {
      console.error('Error loading assets:', error);
    }
  };

  const loadOperationData = async (id: string) => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('operations')
        .select(`
          *,
          investor_account:investor_accounts(id, display_name)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;

      // Set form values
      form.setValue('type', data.type);
      form.setValue('executed_at', data.executed_at);
      form.setValue('notes', data.notes || '');
      if (data.asset_id) {
        form.setValue('asset_id', data.asset_id);
      }

      // Set selected account
      setSelectedAccounts([data.account_id]);
      form.setValue('account_ids', [data.account_id]);

      // Set image preview if exists
      if (data.image_url) {
        setImagePreview(data.image_url);
      }
    } catch (error) {
      console.error('Error loading operation:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os dados da operação.",
      });
      navigate('/app/admin/operations');
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (file: File): Promise<string | null> => {
    try {
      setUploadingImage(true);
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `operations/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('operation-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('operation-images')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        variant: "destructive",
        title: "Erro no upload",
        description: "Não foi possível fazer upload da imagem.",
      });
      return null;
    } finally {
      setUploadingImage(false);
    }
  };

  const onImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      form.setValue('image', file);
    }
  };

  const handleAccountToggle = (accountId: string) => {
    const newSelection = selectedAccounts.includes(accountId)
      ? selectedAccounts.filter(id => id !== accountId)
      : [...selectedAccounts, accountId];
    
    setSelectedAccounts(newSelection);
    form.setValue('account_ids', newSelection);
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setLoading(true);

      let imageUrl = null;
      if (values.image) {
        imageUrl = await handleImageUpload(values.image);
      } else if (isEditing && imagePreview && !values.image) {
        // Keep existing image if no new image uploaded
        imageUrl = imagePreview;
      }

      if (isEditing && operationId) {
        // Update existing operation
        const { error } = await supabase
          .from('operations')
          .update({
            type: values.type,
            asset_id: values.asset_id || null,
            notes: values.notes || null,
            executed_at: values.executed_at,
            image_url: imageUrl,
          })
          .eq('id', operationId);

        if (error) throw error;

        toast({
          title: "Operação atualizada com sucesso!",
          description: "As alterações foram salvas.",
        });
      } else {
        // Create new operations for each selected account
        const operations = values.account_ids.map(accountId => ({
          account_id: accountId,
          type: values.type,
          asset_id: values.asset_id || null,
          quantity: null,
          price: null,
          fee: null,
          notes: values.notes || null,
          executed_at: values.executed_at,
          image_url: imageUrl,
        }));

        const { error } = await supabase
          .from('operations')
          .insert(operations);

        if (error) throw error;

        toast({
          title: "Operações criadas com sucesso!",
          description: `A operação foi adicionada para ${values.account_ids.length} investidor(es).`,
        });
      }

      navigate('/app/admin/operations');
    } catch (error) {
      console.error('Error saving operations:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: isEditing ? "Não foi possível atualizar a operação." : "Não foi possível criar as operações. Tente novamente.",
      });
    } finally {
      setLoading(false);
    }
  };

  const operationTypes = [
    { value: 'buy', label: 'Compra' },
    { value: 'sell', label: 'Venda' },
    { value: 'dividend', label: 'Dividendo' },
    { value: 'split', label: 'Desdobramento' },
    { value: 'merger', label: 'Grupamento' },
    { value: 'other', label: 'Outros' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/app/admin')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">{isEditing ? 'Editar Operação' : 'Nova Operação'}</h1>
          <p className="text-muted-foreground">
            {isEditing ? 'Edite as informações da operação' : 'Registre uma nova operação para investidores'}
          </p>
        </div>
      </div>

      {/* Form */}
      <Card className="card-glass max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Informações da Operação
          </CardTitle>
          <CardDescription>
            Preencha os dados da operação realizada
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="account_ids"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {isEditing ? 'Investidor' : `Investidores (${selectedAccounts.length} selecionado${selectedAccounts.length !== 1 ? 's' : ''})`}
                    </FormLabel>
                    {isEditing ? (
                      <div className="p-3 border border-border rounded-md bg-muted">
                        {accounts.find(acc => acc.id === selectedAccounts[0])?.display_name || 'Carregando...'}
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-48 overflow-y-auto border border-border rounded-md p-3">
                        {accounts.map((account) => (
                          <div key={account.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={account.id}
                              checked={selectedAccounts.includes(account.id)}
                              onCheckedChange={() => handleAccountToggle(account.id)}
                            />
                            <label
                              htmlFor={account.id}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex-1"
                            >
                              {account.display_name} - {account.investor.email}
                            </label>
                          </div>
                        ))}
                        {accounts.length === 0 && (
                          <p className="text-sm text-muted-foreground">Nenhum investidor encontrado</p>
                        )}
                      </div>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Operação</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {operationTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="executed_at"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data da Operação</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="asset_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ativo (Opcional)</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o ativo" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {assets.map((asset) => (
                          <SelectItem key={asset.id} value={asset.id}>
                            {asset.symbol} - {asset.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Adicione observações sobre esta operação..."
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Image Upload */}
              <div className="space-y-4">
                <FormLabel>Imagem da Operação (Opcional)</FormLabel>
                <div className="flex items-center gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    disabled={uploadingImage}
                    onClick={() => document.getElementById('image-upload')?.click()}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {uploadingImage ? 'Enviando...' : 'Escolher Imagem'}
                  </Button>
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={onImageChange}
                  />
                </div>
                
                {imagePreview && (
                  <div className="mt-4">
                    <div className="relative w-48 h-48 border-2 border-dashed border-border rounded-lg overflow-hidden">
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <Button type="submit" disabled={loading || uploadingImage}>
                  {loading ? (isEditing ? 'Salvando...' : 'Salvando...') : (isEditing ? 'Salvar Alterações' : 'Salvar Operação')}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/app/admin/operations')}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}