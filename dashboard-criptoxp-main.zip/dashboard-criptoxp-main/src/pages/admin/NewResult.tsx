import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Calculator } from 'lucide-react';

const formSchema = z.object({
  account_id: z.string().min(1, 'Selecione um investidor'),
  year: z.number().min(2020).max(2030),
  month: z.number().min(1).max(12),
  return_amount: z.number().min(0, 'Valor deve ser positivo'),
  return_percent: z.number().min(-100).max(1000),
  comment: z.string().optional(),
});

interface InvestorAccount {
  id: string;
  display_name: string;
  investor: {
    email: string;
  };
}

export default function NewResult() {
  const [loading, setLoading] = useState(false);
  const [accounts, setAccounts] = useState<InvestorAccount[]>([]);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      return_amount: 0,
      return_percent: 0,
      comment: '',
    },
  });

  useEffect(() => {
    loadInvestorAccounts();
  }, []);

  const loadInvestorAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('investor_accounts')
        .select(`
          id,
          display_name,
          profiles!investor_accounts_investor_id_fkey (
            email
          )
        `);

      if (error) throw error;
      
      // Transform data to match our interface
      const transformedData = data?.map(account => ({
        id: account.id,
        display_name: account.display_name,
        investor: {
          email: account.profiles?.email || 'N/A'
        }
      })) || [];

      setAccounts(transformedData);
    } catch (error) {
      console.error('Error loading accounts:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar as contas dos investidores.",
      });
    }
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setLoading(true);

      const { error } = await supabase
        .from('monthly_results')
        .insert({
          account_id: values.account_id,
          year: values.year,
          month: values.month,
          return_amount: values.return_amount,
          return_percent: values.return_percent,
          comment: values.comment || null,
          created_by: user?.id,
        });

      if (error) throw error;

      toast({
        title: "Resultado criado com sucesso!",
        description: "O resultado mensal foi adicionado ao sistema.",
      });

      navigate('/app/admin');
    } catch (error) {
      console.error('Error creating result:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível criar o resultado. Tente novamente.",
      });
    } finally {
      setLoading(false);
    }
  };

  const months = [
    { value: 1, label: 'Janeiro' },
    { value: 2, label: 'Fevereiro' },
    { value: 3, label: 'Março' },
    { value: 4, label: 'Abril' },
    { value: 5, label: 'Maio' },
    { value: 6, label: 'Junho' },
    { value: 7, label: 'Julho' },
    { value: 8, label: 'Agosto' },
    { value: 9, label: 'Setembro' },
    { value: 10, label: 'Outubro' },
    { value: 11, label: 'Novembro' },
    { value: 12, label: 'Dezembro' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/app/admin')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Novo Resultado Mensal</h1>
          <p className="text-muted-foreground">
            Adicione um resultado mensal para um investidor
          </p>
        </div>
      </div>

      {/* Form */}
      <Card className="card-glass max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Informações do Resultado
          </CardTitle>
          <CardDescription>
            Preencha os dados do resultado mensal do investidor
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="account_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Investidor</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o investidor" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {accounts.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.display_name} - {account.investor.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="year"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ano</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="month"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mês</FormLabel>
                      <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o mês" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {months.map((month) => (
                            <SelectItem key={month.value} value={month.value.toString()}>
                              {month.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="return_amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Valor de Retorno (R$)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0,00"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="return_percent"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Percentual de Retorno (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0,00"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="comment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Comentário (Opcional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Adicione observações sobre este resultado..."
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-3">
                <Button type="submit" disabled={loading}>
                  {loading ? 'Salvando...' : 'Salvar Resultado'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/app/admin')}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}