import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Minus, X, Calendar } from 'lucide-react';

interface InvestorAccount {
  id: string;
  display_name: string;
  investor_id: string;
  profiles: {
    email: string;
  };
}

interface Withdrawal {
  id: string;
  amount: number;
  year: number;
  month: number;
  notes: string | null;
  created_at: string;
  account_id: string;
  investor_account: {
    display_name: string;
    investor: {
      email: string;
    };
  };
}

export default function Withdrawals() {
  const [accounts, setAccounts] = useState<InvestorAccount[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingWithdrawals, setLoadingWithdrawals] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    account_id: '',
    amount: '',
    year: new Date().getFullYear().toString(),
    month: (new Date().getMonth() + 1).toString(),
    notes: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchAccounts();
    fetchWithdrawals();
  }, []);

  const fetchAccounts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('investor_accounts')
        .select(`
          id,
          display_name,
          investor_id,
          profiles!investor_accounts_investor_id_fkey (
            email
          )
        `);

      if (error) throw error;
      setAccounts(data || []);
    } catch (error) {
      console.error('Error fetching accounts:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar contas dos investidores",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchWithdrawals = async () => {
    setLoadingWithdrawals(true);
    try {
      // First, get all withdrawals
      const { data: withdrawalsData, error: withdrawalsError } = await supabase
        .from('withdrawals')
        .select('*')
        .order('created_at', { ascending: false });

      if (withdrawalsError) throw withdrawalsError;

      // Then, get account details for each withdrawal
      const withdrawalsWithAccounts = await Promise.all(
        withdrawalsData?.map(async (withdrawal) => {
          const { data: accountData, error: accountError } = await supabase
            .from('investor_accounts')
            .select(`
              display_name,
              profiles!investor_accounts_investor_id_fkey(email)
            `)
            .eq('id', withdrawal.account_id)
            .single();

          if (accountError) {
            console.error('Error fetching account:', accountError);
            return {
              ...withdrawal,
              investor_account: {
                display_name: 'N/A',
                investor: { email: 'N/A' }
              }
            };
          }

          return {
            ...withdrawal,
            investor_account: {
              display_name: accountData.display_name,
              investor: { email: accountData.profiles?.email || 'N/A' }
            }
          };
        }) || []
      );

      setWithdrawals(withdrawalsWithAccounts);
    } catch (error) {
      console.error('Error fetching withdrawals:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar saques",
        variant: "destructive"
      });
    } finally {
      setLoadingWithdrawals(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.account_id || !formData.amount) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      const { error } = await supabase
        .from('withdrawals')
        .insert({
          account_id: formData.account_id,
          amount: parseFloat(formData.amount),
          year: parseInt(formData.year),
          month: parseInt(formData.month),
          created_by: user.id,
          notes: formData.notes || null
        });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Saque registrado com sucesso",
      });

      // Reset form
      setFormData({
        account_id: '',
        amount: '',
        year: new Date().getFullYear().toString(),
        month: (new Date().getMonth() + 1).toString(),
        notes: ''
      });

      // Refresh withdrawals list
      fetchWithdrawals();

    } catch (error) {
      console.error('Error creating withdrawal:', error);
      toast({
        title: "Erro",
        description: "Erro ao registrar saque",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelWithdrawal = async (withdrawalId: string) => {
    try {
      const { error } = await supabase
        .from('withdrawals')
        .delete()
        .eq('id', withdrawalId);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Saque cancelado com sucesso. O valor foi retornado ao saldo do investidor.",
      });

      // Refresh withdrawals list
      fetchWithdrawals();
    } catch (error) {
      console.error('Error canceling withdrawal:', error);
      toast({
        title: "Erro",
        description: "Erro ao cancelar saque",
        variant: "destructive"
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const getMonthName = (monthNumber: number) => {
    const month = months.find(m => m.value === monthNumber.toString());
    return month?.label || '';
  };

  const months = [
    { value: '1', label: 'Janeiro' },
    { value: '2', label: 'Fevereiro' },
    { value: '3', label: 'Março' },
    { value: '4', label: 'Abril' },
    { value: '5', label: 'Maio' },
    { value: '6', label: 'Junho' },
    { value: '7', label: 'Julho' },
    { value: '8', label: 'Agosto' },
    { value: '9', label: 'Setembro' },
    { value: '10', label: 'Outubro' },
    { value: '11', label: 'Novembro' },
    { value: '12', label: 'Dezembro' }
  ];

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="mobile-container space-y-4 lg:space-y-6">
      <div className="flex items-center gap-2">
        <Minus className="h-5 lg:h-6 w-5 lg:w-6 text-primary" />
        <h1 className="text-2xl lg:text-3xl font-bold">Saques</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg lg:text-xl">Registrar Saque</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="account" className="text-sm lg:text-base">Investidor *</Label>
                <Select
                  value={formData.account_id}
                  onValueChange={(value) => setFormData({ ...formData, account_id: value })}
                >
                  <SelectTrigger className="touch-target">
                    <SelectValue placeholder="Selecione um investidor" />
                  </SelectTrigger>
                  <SelectContent>
                    {accounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        <span className="break-words">
                          {account.display_name} ({account.profiles?.email})
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount" className="text-sm lg:text-base">Valor (R$) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="touch-target"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="year" className="text-sm lg:text-base">Ano *</Label>
                <Select
                  value={formData.year}
                  onValueChange={(value) => setFormData({ ...formData, year: value })}
                >
                  <SelectTrigger className="touch-target">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="month" className="text-sm lg:text-base">Mês *</Label>
                <Select
                  value={formData.month}
                  onValueChange={(value) => setFormData({ ...formData, month: value })}
                >
                  <SelectTrigger className="touch-target">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {months.map((month) => (
                      <SelectItem key={month.value} value={month.value}>
                        {month.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-sm lg:text-base">Observações</Label>
              <Textarea
                id="notes"
                placeholder="Observações sobre o saque..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="touch-target"
              />
            </div>

            <Button 
              type="submit" 
              disabled={submitting}
              className="w-full touch-target"
            >
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Registrar Saque
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Saques Realizados */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Saques Realizados
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loadingWithdrawals ? (
            <div className="flex justify-center items-center h-32">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : withdrawals.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Nenhum saque encontrado
            </p>
          ) : (
            <div className="space-y-4">
              {withdrawals.map((withdrawal) => (
                <Card key={withdrawal.id} className="border-l-4 border-l-orange-500">
                  <CardContent className="pt-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex flex-col gap-1 lg:flex-row lg:items-center lg:gap-4">
                          <h3 className="font-semibold text-base lg:text-lg">
                            {withdrawal.investor_account.display_name}
                          </h3>
                          <span className="text-sm text-muted-foreground break-words">
                            {withdrawal.investor_account.investor.email}
                          </span>
                        </div>
                        <div className="flex flex-col gap-1 lg:flex-row lg:items-center lg:gap-4 text-sm text-muted-foreground">
                          <span>
                            {getMonthName(withdrawal.month)} {withdrawal.year}
                          </span>
                          <span>
                            Criado em {new Date(withdrawal.created_at).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                        <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:gap-6">
                          <div>
                            <span className="text-sm text-muted-foreground">Valor:</span>
                            <p className="text-lg font-semibold text-orange-600">
                              {formatCurrency(withdrawal.amount)}
                            </p>
                          </div>
                          {withdrawal.notes && (
                            <div className="flex-1">
                              <span className="text-sm text-muted-foreground">Observações:</span>
                              <p className="text-sm break-words">{withdrawal.notes}</p>
                            </div>
                          )}
                        </div>
                      </div>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm" className="gap-1 text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground w-full lg:w-auto touch-target">
                            <X className="h-4 w-4" />
                            Cancelar Saque
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Confirmar cancelamento do saque</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja cancelar este saque? O valor de {formatCurrency(withdrawal.amount)} será retornado ao saldo do investidor {withdrawal.investor_account.display_name}.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleCancelWithdrawal(withdrawal.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Confirmar Cancelamento
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}