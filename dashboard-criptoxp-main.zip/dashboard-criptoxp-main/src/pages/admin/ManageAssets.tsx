import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { fetchQuote } from '@/api/quotes';
import { 
  Plus, 
  Pencil, 
  Trash2, 
  User,
  Search,
  DollarSign
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Investor {
  id: string;
  email: string;
  display_name: string;
  account_id: string;
}

interface Asset {
  id: string;
  symbol: string;
  name: string;
  class: string;
}

interface Position {
  id: string;
  account_id: string;
  asset_id: string;
  quantity: number;
  avg_price: number;
  initial_investment: number;
  asset: Asset;
}

interface InvestorSummary {
  id: string;
  email: string;
  display_name: string;
  current_balance: number;
  monthly_return: number;
  account_id: string;
  assets_symbols: string[];
  total_invested: number;
  total_returns: number;
  total_withdrawals: number;
}

export default function ManageAssets() {
  const [investors, setInvestors] = useState<Investor[]>([]);
  const [investorSummaries, setInvestorSummaries] = useState<InvestorSummary[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [selectedInvestor, setSelectedInvestor] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingPosition, setIsAddingPosition] = useState(false);
  const { toast } = useToast();

  // Form states for adding position
  const [selectedAsset, setSelectedAsset] = useState('');
  const [quantity, setQuantity] = useState('');
  const [currentPrice, setCurrentPrice] = useState<number | null>(null);

  // Form states for editing position
  const [editingPosition, setEditingPosition] = useState<Position | null>(null);
  const [isEditingPosition, setIsEditingPosition] = useState(false);
  const [editQuantity, setEditQuantity] = useState('');
  const [editCurrentPrice, setEditCurrentPrice] = useState<number | null>(null);

  // Form states for initial investment
  const [initialInvestmentValue, setInitialInvestmentValue] = useState('');

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    if (selectedInvestor) {
      loadPositions();
      loadInitialInvestment();
    }
  }, [selectedInvestor]);

  const loadInitialData = async () => {
    try {
      setLoading(true);

      // Load investors
      const { data: investorData } = await supabase
        .from('profiles')
        .select(`
          id,
          email,
          investor_accounts!inner (
            id,
            display_name
          )
        `)
        .eq('role', 'investor');

      const investorList: Investor[] = investorData?.map(inv => ({
        id: inv.id,
        email: inv.email,
        display_name: inv.investor_accounts[0]?.display_name || 'Conta Principal',
        account_id: inv.investor_accounts[0]?.id
      })) || [];

      // Load all assets
      const { data: assetData } = await supabase
        .from('assets')
        .select('*')
        .order('symbol');

      setInvestors(investorList);
      setAssets(assetData || []);

      // Load investor summaries
      await loadInvestorSummaries(investorList);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadInvestorSummaries = async (investorList: Investor[]) => {
    try {
      const summaries: InvestorSummary[] = [];
      
      for (const investor of investorList) {
        const accountId = investor.account_id;
        
        // Get actual invested amount from investment_amounts table
        const { data: investmentData } = await supabase
          .from('investment_amounts')
          .select('total_invested')
          .eq('account_id', accountId)
          .maybeSingle();
        
        const totalInvested = investmentData?.total_invested || 0;

        // Get total withdrawals
        const { data: withdrawalsData } = await supabase
          .from('withdrawals')
          .select('amount')
          .eq('account_id', accountId);
        
        const totalWithdrawals = withdrawalsData?.reduce((sum, withdrawal) => sum + Number(withdrawal.amount), 0) || 0;

        // Get all monthly results amounts (sum all months, not just last one)
        const { data: allResultsData } = await supabase
          .from('monthly_results')
          .select('return_amount')
          .eq('account_id', accountId);
          
        const totalReturnsAmount = allResultsData?.reduce((sum, result) => sum + (Number(result.return_amount) || 0), 0) || 0;

        // Get last month's return percentage for display
        const { data: lastMonthData } = await supabase
          .from('monthly_results')
          .select('return_percent')
          .eq('account_id', accountId)
          .order('year', { ascending: false })
          .order('month', { ascending: false })
          .limit(1)
          .maybeSingle();

        const monthlyReturn = lastMonthData?.return_percent || 0;

        // Get positions to calculate assets value and collect symbols
        const { data: positionsDataWithQuantity } = await supabase
          .from('positions')
          .select(`
            quantity,
            assets!inner(symbol)
          `)
          .eq('account_id', accountId);

        // Calculate current value of assets based on live quotes and collect symbols
        let assetsValue = 0;
        const assetsSymbols: string[] = [];
        
        if (positionsDataWithQuantity && positionsDataWithQuantity.length > 0) {
          for (const position of positionsDataWithQuantity) {
            const assetSymbol = position.assets?.symbol;
            if (assetSymbol) {
              if (!assetsSymbols.includes(assetSymbol)) {
                assetsSymbols.push(assetSymbol);
              }
              
              let price = 0;
              if (assetSymbol === 'BTC') {
                const response = await fetchQuote('btcbrl');
                if (response.success && response.data) {
                  price = response.data.price;
                }
              } else if (assetSymbol === 'USDT' || assetSymbol === 'USD') {
                const response = await fetchQuote('usdbrl');
                if (response.success && response.data) {
                  price = response.data.price;
                }
              }
              
              assetsValue += position.quantity * price;
            }
          }
        }

        // Calculate current balance: Valor dos ativos + Retornos - Saques
        const currentBalance = assetsValue + totalReturnsAmount - totalWithdrawals;

        summaries.push({
          id: investor.id,
          email: investor.email,
          display_name: investor.display_name,
          account_id: accountId,
          current_balance: currentBalance,
          monthly_return: monthlyReturn,
          assets_symbols: assetsSymbols,
          total_invested: totalInvested,
          total_returns: totalReturnsAmount,
          total_withdrawals: totalWithdrawals
        });
      }

      setInvestorSummaries(summaries);
    } catch (error) {
      console.error('Error loading investor summaries:', error);
    }
  };

  const loadPositions = async () => {
    if (!selectedInvestor) return;

    try {
      const investor = investors.find(inv => inv.id === selectedInvestor);
      if (!investor) return;

      const { data: positionData } = await supabase
        .from('positions')
        .select(`
          id,
          account_id,
          asset_id,
          quantity,
          avg_price,
          initial_investment,
          assets!inner(
            id,
            symbol,
            name,
            class
          )
        `)
        .eq('account_id', investor.account_id);

      const mappedPositions = positionData?.map(pos => ({
        ...pos,
        asset: pos.assets,
        initial_investment: pos.initial_investment || 0
      })) || [];
      
      setPositions(mappedPositions);
    } catch (error) {
      console.error('Error loading positions:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar posições",
        variant: "destructive",
      });
    }
  };

  const loadInitialInvestment = async () => {
    if (!selectedInvestor) return;

    try {
      const investor = investors.find(inv => inv.id === selectedInvestor);
      if (!investor) return;

      const { data: investmentData } = await supabase
        .from('investment_amounts')
        .select('total_invested')
        .eq('account_id', investor.account_id)
        .maybeSingle();

      setInitialInvestmentValue(investmentData?.total_invested?.toString() || '0');
    } catch (error) {
      console.error('Error loading initial investment:', error);
    }
  };

  const fetchAssetPrice = async (assetSymbol: string) => {
    try {
      let endpoint: 'usdbrl' | 'btcbrl';
      
      if (assetSymbol === 'BTC') {
        endpoint = 'btcbrl';
      } else if (assetSymbol === 'USDT' || assetSymbol === 'USD') {
        endpoint = 'usdbrl';
      } else {
        return null;
      }

      const response = await fetchQuote(endpoint);
      
      if (response.success && response.data) {
        return response.data.price;
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching asset price:', error);
      return null;
    }
  };

  const handleAssetSelection = async (assetId: string) => {
    setSelectedAsset(assetId);
    setCurrentPrice(null);
    
    const asset = assets.find(a => a.id === assetId);
    if (asset) {
      const price = await fetchAssetPrice(asset.symbol);
      setCurrentPrice(price);
    }
  };

  const handleAddPosition = async () => {
    if (!selectedInvestor || !selectedAsset || !quantity || !currentPrice) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    try {
      const investor = investors.find(inv => inv.id === selectedInvestor);
      if (!investor) return;

      // Check if position already exists
      const { data: existingPosition } = await supabase
        .from('positions')
        .select('id')
        .eq('account_id', investor.account_id)
        .eq('asset_id', selectedAsset)
        .maybeSingle();

      if (existingPosition) {
        toast({
          title: "Erro",
          description: "Posição já existe para este ativo",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('positions')
        .insert({
          account_id: investor.account_id,
          asset_id: selectedAsset,
          quantity: parseFloat(quantity),
          avg_price: currentPrice,
          initial_investment: 0
        });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Posição adicionada com sucesso",
      });

      // Reset form
      setSelectedAsset('');
      setQuantity('');
      setCurrentPrice(null);
      setIsAddingPosition(false);
      
      // Reload positions
      loadPositions();
    } catch (error) {
      console.error('Error adding position:', error);
      toast({
        title: "Erro",
        description: "Erro ao adicionar posição",
        variant: "destructive",
      });
    }
  };

  const handleEditPosition = async (position: Position) => {
    setEditingPosition(position);
    setEditQuantity(position.quantity.toString());
    setEditCurrentPrice(null);
    setIsEditingPosition(true);
    
    // Fetch current price for the asset
    const price = await fetchAssetPrice(position.asset.symbol);
    setEditCurrentPrice(price);
  };

  const handleUpdatePosition = async () => {
    if (!editingPosition || !editQuantity || !editCurrentPrice) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('positions')
        .update({
          quantity: parseFloat(editQuantity),
          avg_price: editCurrentPrice
        })
        .eq('id', editingPosition.id);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Posição atualizada com sucesso",
      });

      // Reset form
      setEditingPosition(null);
      setEditQuantity('');
      setEditCurrentPrice(null);
      setIsEditingPosition(false);
      
      // Reload positions
      loadPositions();
    } catch (error) {
      console.error('Error updating position:', error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar posição",
        variant: "destructive",
      });
    }
  };

  const handleDeletePosition = async (positionId: string) => {
    try {
      const { error } = await supabase
        .from('positions')
        .delete()
        .eq('id', positionId);

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Posição removida com sucesso",
      });

      loadPositions();
    } catch (error) {
      console.error('Error deleting position:', error);
      toast({
        title: "Erro",
        description: "Erro ao remover posição",
        variant: "destructive",
      });
    }
  };

  const handleUpdateInitialInvestment = async () => {
    if (!selectedInvestor || !initialInvestmentValue) {
      toast({
        title: "Erro",
        description: "Selecione um investidor e preencha o valor",
        variant: "destructive",
      });
      return;
    }

    try {
      const investor = investors.find(inv => inv.id === selectedInvestor);
      if (!investor) return;

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { error } = await supabase
        .from('investment_amounts')
        .upsert({
          account_id: investor.account_id,
          total_invested: parseFloat(initialInvestmentValue),
          created_by: user.id
        });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Valor inicial atualizado com sucesso",
      });

      // Reload summaries to update the display
      loadInitialData();
    } catch (error) {
      console.error('Error updating initial investment:', error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar valor inicial",
        variant: "destructive",
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(2)}%`;
  };

  const formatQuantity = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
    }).format(value);
  };

  const filteredSummaries = investorSummaries.filter(summary =>
    summary.display_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    summary.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="mobile-container flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-container space-y-4 lg:space-y-6">
      <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between mb-4 lg:mb-6">
        <div>
          <h1 className="text-xl lg:text-2xl font-bold">Gestão de Ativos</h1>
          <p className="text-sm lg:text-base text-muted-foreground">
            Gerencie os ativos e carteiras dos investidores
          </p>
        </div>
      </div>

      {/* Investor Summaries */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg lg:text-xl">Resumo dos Investidores</CardTitle>
          <CardDescription className="text-sm lg:text-base">
            Visão geral de todos os investidores e seus portfólios
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-sm lg:text-base touch-target"
              />
            </div>
          </div>

          {filteredSummaries.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground text-sm lg:text-base">
                {searchTerm ? 'Nenhum investidor encontrado.' : 'Nenhum investidor cadastrado.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredSummaries.map((summary) => (
                <Card key={summary.id} className="hover:bg-accent/50 transition-colors">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <h3 className="font-medium text-sm lg:text-base">{summary.display_name}</h3>
                        </div>
                        <p className="text-xs lg:text-sm text-muted-foreground break-words">{summary.email}</p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {summary.assets_symbols.map((symbol) => (
                            <Badge key={symbol} variant="outline" className="text-xs">
                              {symbol}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-xs text-muted-foreground">Saldo Atual</p>
                          <p className="font-medium text-green-600 text-sm">
                            {formatCurrency(summary.current_balance)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Investido</p>
                          <p className="font-medium text-sm">
                            {formatCurrency(summary.total_invested)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Retornos</p>
                          <p className="font-medium text-blue-600 text-sm">
                            {formatCurrency(summary.total_returns)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Último Retorno</p>
                          <p className="font-medium text-sm">
                            {summary.monthly_return.toFixed(2)}%
                          </p>
                        </div>
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedInvestor(summary.id)}
                        className="w-full touch-target"
                      >
                        Gerenciar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Individual Investor Management */}
      {selectedInvestor && (
        <div className="space-y-4 lg:space-y-6">
          {/* Position Management */}
          <Card>
            <CardHeader>
              <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <CardTitle className="text-lg lg:text-xl">Posições do Investidor</CardTitle>
                  <CardDescription className="text-sm lg:text-base">
                    Gerencie as posições em ativos do investidor selecionado
                  </CardDescription>
                </div>
                <Button onClick={() => setIsAddingPosition(true)} size="sm" className="touch-target">
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Posição
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {positions.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground text-sm lg:text-base">Nenhuma posição encontrada</p>
                  <Button onClick={() => setIsAddingPosition(true)} className="mt-4 touch-target">
                    Adicionar Primeira Posição
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {positions.map((position) => (
                    <Card key={position.id} className="border-l-4 border-l-primary">
                      <CardContent className="p-4">
                        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                          <div className="space-y-2">
                            <h4 className="font-medium text-sm lg:text-base">
                              {position.asset.name} ({position.asset.symbol})
                            </h4>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div>
                                <span className="text-muted-foreground">Quantidade: </span>
                                <span className="font-medium">{formatQuantity(position.quantity)}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Preço Médio: </span>
                                <span className="font-medium">{formatCurrency(position.avg_price)}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditPosition(position)}
                              className="flex-1 lg:flex-none touch-target"
                            >
                              <Pencil className="h-4 w-4 mr-1" />
                              Editar
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeletePosition(position.id)}
                              className="flex-1 lg:flex-none text-destructive hover:bg-destructive hover:text-destructive-foreground touch-target"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Excluir
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Initial Investment Management */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg lg:text-xl">Valor Inicial Investido</CardTitle>
              <CardDescription className="text-sm lg:text-base">
                Configure o valor total investido pelo investidor
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end">
                <div className="flex-1">
                  <Label htmlFor="initial-investment" className="text-sm lg:text-base">Valor Total Investido (R$)</Label>
                  <Input
                    id="initial-investment"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={initialInvestmentValue}
                    onChange={(e) => setInitialInvestmentValue(e.target.value)}
                    className="mt-2 touch-target"
                  />
                </div>
                <Button onClick={handleUpdateInitialInvestment} className="touch-target">
                  <DollarSign className="h-4 w-4 mr-2" />
                  Atualizar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Add Position Dialog */}
      <Dialog open={isAddingPosition} onOpenChange={setIsAddingPosition}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Adicionar Posição</DialogTitle>
            <DialogDescription>
              Adicione uma nova posição para o investidor selecionado
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="asset-select">Ativo</Label>
              <Select value={selectedAsset} onValueChange={handleAssetSelection}>
                <SelectTrigger className="touch-target">
                  <SelectValue placeholder="Selecione um ativo" />
                </SelectTrigger>
                <SelectContent>
                  {assets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id}>
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="quantity-input">Quantidade</Label>
              <Input
                id="quantity-input"
                type="number"
                step="0.00000001"
                placeholder="0.0"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="touch-target"
              />
            </div>

            {currentPrice && (
              <div>
                <Label>Preço Atual</Label>
                <p className="text-lg font-semibold text-green-600">
                  {formatCurrency(currentPrice)}
                </p>
              </div>
            )}
          </div>
          <DialogFooter className="flex-col lg:flex-row gap-2">
            <Button variant="outline" onClick={() => setIsAddingPosition(false)} className="touch-target">
              Cancelar
            </Button>
            <Button onClick={handleAddPosition} className="touch-target">
              Adicionar Posição
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Position Dialog */}
      <Dialog open={isEditingPosition} onOpenChange={setIsEditingPosition}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Editar Posição</DialogTitle>
            <DialogDescription>
              Atualize a quantidade e preço da posição
            </DialogDescription>
          </DialogHeader>
          {editingPosition && (
            <div className="space-y-4">
              <div>
                <Label>Ativo</Label>
                <p className="font-medium">
                  {editingPosition.asset.name} ({editingPosition.asset.symbol})
                </p>
              </div>

              <div>
                <Label htmlFor="edit-quantity">Quantidade</Label>
                <Input
                  id="edit-quantity"
                  type="number"
                  step="0.00000001"
                  placeholder="0.0"
                  value={editQuantity}
                  onChange={(e) => setEditQuantity(e.target.value)}
                  className="touch-target"
                />
              </div>

              {editCurrentPrice && (
                <div>
                  <Label>Preço Atual</Label>
                  <p className="text-lg font-semibold text-green-600">
                    {formatCurrency(editCurrentPrice)}
                  </p>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="flex-col lg:flex-row gap-2">
            <Button variant="outline" onClick={() => setIsEditingPosition(false)} className="touch-target">
              Cancelar
            </Button>
            <Button onClick={handleUpdatePosition} className="touch-target">
              Atualizar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
