import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Settings, User, Mail, Lock, Upload, Camera, Calendar as CalendarIcon, TrendingUp } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

const profileSchema = z.object({
  email: z.string().email('E-mail inválido'),
  username: z.string().min(3, 'Nome de usuário deve ter pelo menos 3 caracteres').optional(),
  full_name: z.string().min(2, 'Nome completo deve ter pelo menos 2 caracteres').optional(),
  birth_date: z.date({
    required_error: "Data de nascimento é obrigatória.",
  }).optional(),
  investment_profile: z.enum(['conservador', 'agressivo'], {
    required_error: "Selecione um perfil de investimento.",
  }).optional(),
});

const passwordSchema = z.object({
  new_password: z.string().min(6, 'Nova senha deve ter pelo menos 6 caracteres'),
  confirm_password: z.string().min(6, 'Confirmação de senha é obrigatória'),
}).refine((data) => data.new_password === data.confirm_password, {
  message: "Senhas não coincidem",
  path: ["confirm_password"],
});

export default function AccountSettings() {
  const [loading, setLoading] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const profileForm = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      email: '',
      username: '',
      full_name: '',
      birth_date: undefined,
      investment_profile: undefined,
    },
  });

  const passwordForm = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      new_password: '',
      confirm_password: '',
    },
  });

  useEffect(() => {
    if (profile) {
      profileForm.reset({
        email: profile.email || '',
        username: profile.username || '',
        full_name: profile.full_name || '',
        birth_date: profile.birth_date ? new Date(profile.birth_date + 'T00:00:00') : undefined,
        investment_profile: profile.investment_profile || undefined,
      });
      setAvatarPreview(profile.avatar_url || null);
    }
  }, [profile, profileForm]);

  const handleAvatarUpload = async (file: File): Promise<string | null> => {
    try {
      setUploadingAvatar(true);
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${user?.id}/${Date.now()}.${fileExt}`;
      const filePath = fileName;

      // Remove old avatar if exists
      if (profile?.avatar_url) {
        const oldPath = profile.avatar_url.split('/avatars/')[1];
        if (oldPath) {
          await supabase.storage.from('avatars').remove([oldPath]);
        }
      }

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({
        variant: "destructive",
        title: "Erro no upload",
        description: "Não foi possível fazer upload da foto.",
      });
      return null;
    } finally {
      setUploadingAvatar(false);
    }
  };

  const onAvatarChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setAvatarPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);

      // Upload avatar
      const avatarUrl = await handleAvatarUpload(file);
      if (avatarUrl) {
        // Update profile with new avatar URL
        const { error } = await supabase
          .from('profiles')
          .update({ avatar_url: avatarUrl })
          .eq('id', user?.id);

        if (error) {
          console.error('Error updating avatar:', error);
          toast({
            variant: "destructive",
            title: "Erro",
            description: "Não foi possível atualizar a foto.",
          });
        } else {
          toast({
            title: "Foto atualizada!",
            description: "Sua foto de perfil foi atualizada com sucesso.",
          });
        }
      }
    }
  };

  const onProfileSubmit = async (values: z.infer<typeof profileSchema>) => {
    try {
      setLoading(true);
      console.log('=== Profile Submit Debug ===');
      console.log('Current user:', user);
      console.log('Current profile:', profile);
      console.log('Form values:', values);

      // Update email in auth if changed
      if (values.email !== profile?.email) {
        console.log('Updating email in auth...');
        const { error: emailError } = await supabase.auth.updateUser({
          email: values.email,
        });

        if (emailError) throw emailError;

        toast({
          title: "E-mail atualizado!",
          description: "Verifique seu novo e-mail para confirmar a alteração.",
        });
      }

      // Update profile data
      const updateData = {
        username: values.username || null,
        full_name: values.full_name || null,
        birth_date: values.birth_date ? values.birth_date.toISOString().split('T')[0] : null,
        investment_profile: values.investment_profile || null,
      };
      
      console.log('Updating profile with data:', updateData);
      console.log('User ID:', user?.id);

      const { data: updateResult, error: profileError } = await supabase
        .from('profiles')
        .update(updateData)
        .eq('id', user?.id)
        .select();

      console.log('Profile update result:', updateResult);
      console.log('Profile update error:', profileError);
      
      if (profileError) throw profileError;

      if (updateResult && updateResult.length === 0) {
        console.error('No rows were updated. This could indicate an RLS policy issue.');
        throw new Error('Nenhuma linha foi atualizada. Verifique suas permissões.');
      }

      // Force refresh of profile data
      await refreshProfile();

      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso.",
      });

    } catch (error: any) {
      console.error('Error updating profile:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message || "Não foi possível atualizar o perfil.",
      });
    } finally {
      setLoading(false);
    }
  };

  const onPasswordSubmit = async (values: z.infer<typeof passwordSchema>) => {
    try {
      setLoading(true);

      const { error } = await supabase.auth.updateUser({
        password: values.new_password,
      });

      if (error) throw error;

      toast({
        title: "Senha atualizada!",
        description: "Sua senha foi alterada com sucesso.",
      });

      passwordForm.reset();

    } catch (error: any) {
      console.error('Error updating password:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message || "Não foi possível alterar a senha.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Configurações da Conta</h1>
          <p className="text-muted-foreground">
            Gerencie suas informações pessoais e configurações de segurança
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Avatar Section */}
        <Card className="card-glass">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5" />
              Foto do Perfil
            </CardTitle>
            <CardDescription>
              Clique na foto para alterar sua imagem de perfil
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Avatar className="w-24 h-24 cursor-pointer hover:opacity-75 transition-opacity">
                <AvatarImage 
                  src={avatarPreview || profile?.avatar_url || ''} 
                  alt="Avatar" 
                />
                <AvatarFallback className="text-lg">
                  {profile?.full_name?.charAt(0) || profile?.email?.charAt(0)?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                <Upload className="h-6 w-6 text-white" />
              </div>
              <input
                type="file"
                accept="image/*"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                onChange={onAvatarChange}
                disabled={uploadingAvatar}
              />
            </div>
            {uploadingAvatar && (
              <p className="text-sm text-muted-foreground">Enviando foto...</p>
            )}
          </CardContent>
        </Card>

        {/* Profile Information */}
        <Card className="card-glass">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Informações Pessoais
            </CardTitle>
            <CardDescription>
              Atualize suas informações básicas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...profileForm}>
              <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                <FormField
                  control={profileForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>E-mail</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={profileForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome de Usuário</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Opcional" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={profileForm.control}
                  name="full_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome Completo</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Opcional" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                 />

                <FormField
                  control={profileForm.control}
                  name="birth_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Nascimento</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP", { locale: ptBR })
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) =>
                              date > new Date() || date < new Date("1900-01-01")
                            }
                            defaultMonth={field.value}
                            captionLayout="dropdown-buttons"
                            fromYear={1900}
                            toYear={new Date().getFullYear()}
                            initialFocus
                            className={cn("p-3 pointer-events-auto")}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        Sua data de nascimento será usada para cálculos de perfil de risco.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={profileForm.control}
                  name="investment_profile"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Perfil de Investimento</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione seu perfil" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="conservador">Conservador</SelectItem>
                          <SelectItem value="agressivo">Agressivo</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Defina seu perfil para receber recomendações personalizadas.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" disabled={loading}>
                  {loading ? 'Salvando...' : 'Salvar Alterações'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Investment Profile Section */}
        <Card className="card-glass lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Perfil de Investimento
            </CardTitle>
            <CardDescription>
              Configure suas preferências de investimento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className={cn(
                  "p-4 border rounded-lg transition-all",
                  profile?.investment_profile === 'conservador' 
                    ? "bg-primary/10 border-primary text-primary" 
                    : "border-border"
                )}>
                  <h3 className="font-medium text-sm">Conservador</h3>
                  <p className="text-xs opacity-70 mt-1">
                    Prioriza segurança e estabilidade com menor volatilidade nos investimentos.
                  </p>
                </div>
                <div className={cn(
                  "p-4 border rounded-lg transition-all",
                  profile?.investment_profile === 'agressivo' 
                    ? "bg-primary/10 border-primary text-primary" 
                    : "border-border"
                )}>
                  <h3 className="font-medium text-sm">Agressivo</h3>
                  <p className="text-xs opacity-70 mt-1">
                    Busca maiores retornos e aceita maior volatilidade nos investimentos.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Password Change */}
        <Card className="card-glass lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Alterar Senha
            </CardTitle>
            <CardDescription>
              Atualize sua senha para manter sua conta segura
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...passwordForm}>
              <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={passwordForm.control}
                    name="new_password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nova Senha</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={passwordForm.control}
                    name="confirm_password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirmar Nova Senha</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" disabled={loading}>
                  {loading ? 'Alterando...' : 'Alterar Senha'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}