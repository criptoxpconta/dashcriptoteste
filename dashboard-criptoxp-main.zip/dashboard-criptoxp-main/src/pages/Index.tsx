import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import PerformanceImage from "@/components/ui/performance-image";
import { IntersectionObserverWrapper } from "@/components/ui/intersection-observer";
import { useTheme } from "next-themes";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import StructuredData from "@/components/seo/StructuredData";
import {
  TrendingUp, 
  Shield, 
  BarChart3, 
  Users, 
  Briefcase,
  CheckCircle,
  ArrowRight
} from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { theme } = useTheme();

  const getDashboardPath = () => {
    if (profile?.role === 'admin') return '/app/admin';
    if (profile?.role === 'investor') return '/app/investidor';
    return '/login';
  };

  const features = [
    {
      icon: TrendingUp,
      title: "Análise de Performance",
      description: "Acompanhe a evolução dos seus investimentos com gráficos detalhados e KPIs em tempo real."
    },
    {
      icon: Shield,
      title: "Segurança Total",
      description: "Dados protegidos com criptografia avançada e controle de acesso baseado em funções."
    },
    {
      icon: BarChart3,
      title: "Dashboards Intuitivos",
      description: "Interface limpa e moderna para visualizar seus dados de investimento de forma clara."
    },
    {
      icon: Users,
      title: "Gestão Profissional",
      description: "Ferramenta completa para gestores administrarem carteiras de múltiplos investidores."
    }
  ];

  const benefits = [
    "Visualização em tempo real do patrimônio",
    "Relatórios mensais automatizados",
    "Controle total de operações",
    "Interface responsiva para mobile",
    "Segurança de dados garantida",
    "Suporte técnico especializado"
  ];

  return (
    <>
      {/* Structured Data for SEO */}
      <StructuredData type="website" />
      <StructuredData type="organization" />
      <StructuredData type="service" />
      
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur-sm supports-[backdrop-filter]:bg-card/60 safe-top">
        <div className="mobile-container">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center">
              <PerformanceImage
                src={theme === 'dark' ? "/lovable-uploads/dfef5ea2-b978-4f62-b3d6-c196967882a7.png" : "/lovable-uploads/a62c4ed4-d657-4d7a-b950-74e68e753e60.png"}
                alt="CriptoXP - Plataforma de Gestão de Criptoativos"
                className="h-8 w-auto"
                priority={true}
                sizes="(max-width: 768px) 120px, 160px"
              />
            </div>
            <nav className="flex items-center gap-2 sm:gap-4" role="navigation" aria-label="Menu principal">
              {user ? (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={() => navigate(getDashboardPath())}
                    className="hidden sm:inline-flex focus-ring"
                  >
                    {profile?.role === 'admin' ? 'Painel Admin' : 'Meu Dashboard'}
                  </Button>
                   <Button 
                     variant="outline" 
                     onClick={() => navigate('/app/settings')}
                     className="text-sm focus-ring truncate max-w-[120px] sm:max-w-none touch-target"
                     title={user.email}
                   >
                     <span className="truncate">{user.email}</span>
                   </Button>
                </>
              ) : (
                <>
                   <Button 
                     variant="ghost" 
                     onClick={() => navigate('/login')}
                     className="focus-ring touch-target"
                   >
                     Entrar
                   </Button>
                   <Button 
                     onClick={() => navigate('/signup')}
                     className="focus-ring touch-target"
                   >
                     <span className="hidden sm:inline">Criar Conta</span>
                     <span className="sm:hidden">Cadastro</span>
                   </Button>
                </>
              )}
              <ThemeToggle />
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main>
        <section className="mobile-container py-12 sm:py-16 lg:py-20 text-center">
          <div className="fade-in visible">
            <Badge variant="secondary" className="mb-4 sm:mb-6">
              Plataforma de Gestão de Investimentos
            </Badge>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 sm:mb-8 lg:mb-10 gradient-primary bg-clip-text text-transparent leading-relaxed">
              Gerencie seus criptoativos
              <br className="hidden sm:block" />
              <span className="sm:hidden"> </span>de forma inteligente
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-2xl mx-auto leading-relaxed">
              Plataforma completa para acompanhar, analisar e otimizar seus criptoativos. 
              Interface profissional com dados em tempo real e relatórios detalhados.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
              <Button 
                size="lg" 
                onClick={() => navigate('/signup')} 
                className="w-full sm:w-auto gap-2 focus-ring touch-target"
              >
                Começar Agora
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                onClick={() => navigate('/login')}
                className="w-full sm:w-auto focus-ring touch-target"
              >
                Fazer Login
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <IntersectionObserverWrapper rootMargin="100px">
          <section className="mobile-container py-12 sm:py-16 lg:py-20">
            <div className="text-center mb-8 sm:mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">Recursos Principais</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto text-base sm:text-lg">
                Tudo que você precisa para gerenciar seus criptoativos de forma profissional
              </p>
            </div>
            <div className="mobile-grid">
              {features.map((feature, index) => (
                <Card 
                  key={index} 
                  className="card-glass text-center hover:shadow-lg transition-all duration-200 group mobile-card gpu-accelerated"
                >
                  <CardHeader className="pb-4">
                    <feature.icon className="h-10 w-10 sm:h-12 sm:w-12 text-primary mx-auto mb-3 sm:mb-4 group-hover:scale-110 transition-transform duration-200 gpu-accelerated" />
                    <CardTitle className="text-base sm:text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm sm:text-base leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        </IntersectionObserverWrapper>


        {/* CTA Section */}
        <IntersectionObserverWrapper rootMargin="50px">
          <section className="mobile-container py-12 sm:py-16 lg:py-20">
            <Card className="gradient-card text-center mobile-card border-0 shadow-xl gpu-accelerated">
              <h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">
                Pronto para otimizar seus investimentos em criptoativos?
              </h2>
              <p className="text-muted-foreground mb-6 sm:mb-8 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
                Junte-se a milhares de investidores que já utilizam nossa plataforma 
                para maximizar seus retornos.
              </p>
              <Button 
                size="lg" 
                onClick={() => navigate('/signup')}
                className="focus-ring touch-target button-press"
              >
                Criar Conta Grátis
              </Button>
            </Card>
          </section>
        </IntersectionObserverWrapper>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 backdrop-blur-sm safe-bottom">
        <div className="mobile-container py-6 sm:py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center">
              <PerformanceImage
                src={theme === 'dark' ? "/lovable-uploads/dfef5ea2-b978-4f62-b3d6-c196967882a7.png" : "/lovable-uploads/a62c4ed4-d657-4d7a-b950-74e68e753e60.png"}
                alt="CriptoXP"
                className="h-6 w-auto"
                priority={false}
                sizes="96px"
              />
            </div>
            <div className="text-xs sm:text-sm text-muted-foreground text-center sm:text-right">
              © 2025 CriptoXP. Todos os direitos reservados.
            </div>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
};

export default Index;
