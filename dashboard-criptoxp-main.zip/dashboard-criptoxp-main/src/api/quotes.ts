import { QuoteData, QuoteResponse } from '@/components/quotes/types';

// Simple in-memory cache for both quotes
const cache = new Map<string, { data: QuoteData; timestamp: number }>();
const CACHE_DURATION = 60 * 1000; // 60 seconds

async function fetchUsdBrlFromAwesome(): Promise<QuoteData> {
  const response = await fetch('https://economia.awesomeapi.com.br/json/last/USD-BRL');
  
  if (!response.ok) {
    throw new Error(`AwesomeAPI error: ${response.status}`);
  }

  const data = await response.json();
  const usdBrl = data.USDBRL;

  if (!usdBrl) {
    throw new Error('Invalid AwesomeAPI response format');
  }

  return {
    price: parseFloat(usdBrl.bid),
    change24h: parseFloat(usdBrl.varBid),
    changePct24h: parseFloat(usdBrl.pctChange),
    source: 'AwesomeAPI',
    updatedAt: new Date().toISOString(),
  };
}

async function fetchBtcBrlFromBinance(): Promise<QuoteData> {
  const response = await fetch('https://api.binance.com/api/v3/ticker/24hr?symbol=BTCBRL');
  
  if (!response.ok) {
    throw new Error(`Binance API error: ${response.status}`);
  }

  const data = await response.json();

  return {
    price: parseFloat(data.lastPrice),
    change24h: parseFloat(data.priceChange),
    changePct24h: parseFloat(data.priceChangePercent),
    source: 'Binance',
    updatedAt: new Date().toISOString(),
  };
}

async function fetchBtcBrlFromCoinGecko(): Promise<QuoteData> {
  const response = await fetch(
    'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=brl&include_24hr_change=true'
  );

  if (!response.ok) {
    throw new Error(`CoinGecko API error: ${response.status}`);
  }

  const data = await response.json();
  const btcData = data.bitcoin;

  if (!btcData) {
    throw new Error('Invalid CoinGecko response format');
  }

  const price = btcData.brl;
  const changePct24h = btcData.brl_24h_change || 0;
  const change24h = (price * changePct24h) / 100;

  return {
    price,
    change24h,
    changePct24h,
    source: 'CoinGecko',
    updatedAt: new Date().toISOString(),
  };
}

export async function fetchQuote(type: 'usdbrl' | 'btcbrl'): Promise<QuoteResponse> {
  try {
    // Check cache first
    const cached = cache.get(type);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      return { success: true, data: cached.data };
    }

    let data: QuoteData;

    if (type === 'usdbrl') {
      data = await fetchUsdBrlFromAwesome();
    } else {
      try {
        data = await fetchBtcBrlFromBinance();
      } catch (binanceError) {
        console.warn('Binance failed, trying CoinGecko fallback:', binanceError);
        data = await fetchBtcBrlFromCoinGecko();
      }
    }
    
    // Update cache
    cache.set(type, { data, timestamp: Date.now() });
    
    return { success: true, data };
  } catch (error) {
    console.error(`Error fetching ${type} quote:`, error);
    
    // Return cached data if available, even if stale
    const cached = cache.get(type);
    if (cached) {
      return { 
        success: true, 
        data: { ...cached.data, source: `${cached.data.source} (cached)` }
      };
    }
    
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    };
  }
}