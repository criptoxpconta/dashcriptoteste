export interface QuoteData {
  price: number;
  change24h: number;
  changePct24h: number;
  source: string;
  updatedAt: string;
}

export interface QuoteResponse {
  success: boolean;
  data?: QuoteData;
  error?: string;
}