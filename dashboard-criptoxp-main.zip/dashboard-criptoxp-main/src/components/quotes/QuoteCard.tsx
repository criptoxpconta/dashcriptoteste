import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, TrendingUp, TrendingDown } from 'lucide-react';
import { QuoteData, QuoteResponse } from './types';
import { fetchQuote as fetchQuoteData } from '@/api/quotes';

interface QuoteCardProps {
  title: string;
  endpoint: 'usdbrl' | 'btcbrl';
  className?: string;
}

export function QuoteCard({ title, endpoint, className }: QuoteCardProps) {
  const [data, setData] = useState<QuoteData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchQuote = useCallback(async (showRefreshing = false) => {
    try {
      if (showRefreshing) setRefreshing(true);
      setError(null);

      const response = await fetchQuoteData(endpoint);

      if (response.success && response.data) {
        setData(response.data);
      } else {
        setError(response.error || 'Erro desconhecido');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao buscar cotação');
    } finally {
      setLoading(false);
      if (showRefreshing) setRefreshing(false);
    }
  }, [endpoint]);

  const handleRefresh = () => {
    fetchQuote(true);
  };

  useEffect(() => {
    fetchQuote();

    // Auto-refresh every 60 seconds
    const refreshMs = 60000; // 60 seconds default
    const interval = setInterval(() => fetchQuote(), refreshMs);

    return () => clearInterval(interval);
  }, [fetchQuote]);

  const formatCurrency = (value: number) => {
    if (endpoint === 'btcbrl') {
      // For Bitcoin, format as whole numbers without decimals
      return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(value);
    } else {
      // For USD/BRL, show up to 4 decimal places
      return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 2,
        maximumFractionDigits: 4,
      }).format(value);
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  if (loading) {
    return (
      <Card className={`card-glass ${className}`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">{title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-9 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={`card-glass border-destructive/50 ${className}`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">{title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-destructive">Erro: {error}</p>
          <Button 
            onClick={handleRefresh} 
            disabled={refreshing}
            variant="outline" 
            size="sm" 
            className="w-full"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Tentar novamente
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return null;
  }

  const isPositive = data.changePct24h >= 0;

  return (
    <Card className={`card-glass ${className}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Price */}
        <div className="text-2xl font-bold text-card-foreground">
          {formatCurrency(data.price)}
        </div>

        {/* 24h Change */}
        <div className="flex items-center gap-2">
          <Badge 
            variant={isPositive ? "default" : "destructive"}
            className="flex items-center gap-1"
          >
            {isPositive ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            {isPositive ? '+' : ''}{data.changePct24h.toFixed(2)}%
          </Badge>
          <span className={`text-sm ${isPositive ? 'text-profit' : 'text-loss'}`}>
            {isPositive ? '+' : ''}{formatCurrency(data.change24h)}
          </span>
        </div>

        {/* Last update */}
        <p className="text-xs text-muted-foreground">
          Última atualização: {formatTime(data.updatedAt)}
        </p>

        {/* Source badge */}
        <Badge variant="outline" className="text-xs">
          Fonte: {data.source}
        </Badge>

        {/* Refresh button */}
        <Button 
          onClick={handleRefresh} 
          disabled={refreshing}
          variant="outline" 
          size="sm" 
          className="w-full"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Atualizar agora
        </Button>
      </CardContent>
    </Card>
  );
}