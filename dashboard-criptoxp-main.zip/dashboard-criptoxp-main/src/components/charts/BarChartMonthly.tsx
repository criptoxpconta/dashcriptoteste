import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface BarChartMonthlyProps {
  data: Array<{
    month: string;
    return: number;
  }>;
}

export function BarChartMonthly({ data }: BarChartMonthlyProps) {
  const formatPercent = (value: number) => {
    return `${value.toFixed(2)}%`;
  };

  const formatMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleDateString('pt-BR', {
      month: 'short',
      year: '2-digit',
    });
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const value = payload[0].value;
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium">{formatMonth(label)}</p>
          <p className={`text-sm ${value >= 0 ? 'text-profit' : 'text-loss'}`}>
            Retorno: {formatPercent(value)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
          <XAxis 
            dataKey="month" 
            tickFormatter={formatMonth}
            className="text-xs"
          />
          <YAxis 
            tickFormatter={formatPercent}
            className="text-xs"
          />
          <Tooltip content={<CustomTooltip />} />
          <Bar 
            dataKey="return" 
            fill="hsl(var(--primary))"
            radius={[2, 2, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}