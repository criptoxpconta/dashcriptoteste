import { Suspense, lazy } from 'react';
import { Loader2 } from 'lucide-react';

interface LazyComponentProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

const defaultFallback = (
  <div className="flex items-center justify-center p-4">
    <Loader2 className="h-6 w-6 animate-spin" />
  </div>
);

export function LazyComponent({ children, fallback = defaultFallback }: LazyComponentProps) {
  return (
    <Suspense fallback={fallback}>
      {children}
    </Suspense>
  );
}

// Helper to create lazy-loaded components with better error boundaries
export function createLazyComponent<T extends React.ComponentType<any>>(
  importFn: () => Promise<{ default: T }>,
  displayName?: string
) {
  const LazyComp = lazy(importFn);
  // Set displayName for debugging purposes
  if (displayName) {
    (LazyComp as any).displayName = displayName;
  }
  return LazyComp;
}