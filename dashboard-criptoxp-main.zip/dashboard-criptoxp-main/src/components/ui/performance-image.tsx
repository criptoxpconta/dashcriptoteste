import React, { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface PerformanceImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
  onLoadComplete?: () => void;
  sizes?: string;
  quality?: number;
  fallbackSrc?: string;
  lazyOffset?: number;
  placeholder?: 'blur' | 'empty';
}

export default function PerformanceImage({
  src,
  alt,
  className,
  priority = false,
  onLoadComplete,
  sizes,
  quality = 75,
  fallbackSrc,
  lazyOffset = 100,
  placeholder = 'blur',
  ...props
}: PerformanceImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInView, setIsInView] = useState(priority);
  const [hasError, setHasError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState(priority ? src : '');
  const imgRef = useRef<HTMLImageElement>(null);

  // Intersection Observer for lazy loading
  useEffect(() => {
    if (priority || isInView) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          setCurrentSrc(src);
          observer.disconnect();
        }
      },
      {
        rootMargin: `${lazyOffset}px`,
        threshold: 0.1,
      }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => observer.disconnect();
  }, [src, priority, isInView, lazyOffset]);

  const handleLoad = () => {
    setIsLoaded(true);
    setHasError(false);
    onLoadComplete?.();
  };

  const handleError = () => {
    setHasError(true);
    if (fallbackSrc && currentSrc !== fallbackSrc) {
      setCurrentSrc(fallbackSrc);
      setHasError(false);
    }
  };

  // Placeholder dimensions based on aspect ratio
  const getPlaceholderStyle = () => {
    if (placeholder === 'empty') return {};
    
    return {
      backgroundColor: 'hsl(var(--muted))',
      backgroundImage: `
        linear-gradient(
          90deg,
          transparent,
          rgba(255, 255, 255, 0.1) 50%,
          transparent
        )
      `,
      backgroundSize: '200% 100%',
      animation: isLoaded ? 'none' : 'shimmer 1.5s infinite',
    };
  };

  return (
    <div
      ref={imgRef}
      className={cn(
        'relative overflow-hidden',
        !isLoaded && placeholder === 'blur' && 'animate-pulse',
        className
      )}
      style={{
        ...(!isLoaded && getPlaceholderStyle()),
      }}
    >
      {currentSrc && (
        <img
          src={currentSrc}
          alt={alt}
          sizes={sizes}
          loading={priority ? 'eager' : 'lazy'}
          decoding={priority ? 'sync' : 'async'}
          fetchPriority={priority ? 'high' : 'low'}
          onLoad={handleLoad}
          onError={handleError}
          className={cn(
            'responsive-image transition-opacity duration-300',
            isLoaded ? 'opacity-100' : 'opacity-0',
            hasError && 'opacity-50'
          )}
          style={{
            position: isLoaded ? 'static' : 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
          {...props}
        />
      )}
      
      {/* Error state */}
      {hasError && !fallbackSrc && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted text-muted-foreground text-sm">
          <span>Imagem não disponível</span>
        </div>
      )}
      
      {/* Shimmer animation is handled via CSS in index.css */}
    </div>
  );
}