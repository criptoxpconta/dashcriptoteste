import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface CardKPIProps {
  title: string;
  value: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon?: LucideIcon;
  className?: string;
}

export function CardKPI({ 
  title, 
  value, 
  change, 
  changeType = 'neutral', 
  icon: Icon,
  className 
}: CardKPIProps) {
  return (
    <Card className={cn("card-glass", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xs lg:text-sm font-medium text-muted-foreground leading-tight">
          {title}
        </CardTitle>
        {Icon && <Icon className="h-3 w-3 lg:h-4 lg:w-4 text-muted-foreground flex-shrink-0" />}
      </CardHeader>
      <CardContent className="pt-0">
        <div className="text-sm lg:text-2xl font-bold text-card-foreground leading-tight break-all">{value}</div>
        {change && (
          <p className={cn(
            "text-xs mt-1 leading-tight",
            changeType === 'positive' && "text-profit",
            changeType === 'negative' && "text-loss",
            changeType === 'neutral' && "text-muted-foreground"
          )}>
            {change}
          </p>
        )}
      </CardContent>
    </Card>
  );
}