import React, { useEffect, useRef, useState, type ReactNode } from 'react';

interface IntersectionObserverProps {
  children: ReactNode;
  onIntersect?: () => void;
  rootMargin?: string;
  threshold?: number | number[];
  triggerOnce?: boolean;
  className?: string;
  fallback?: ReactNode;
}

export function IntersectionObserverWrapper({
  children,
  onIntersect,
  rootMargin = '50px',
  threshold = 0.1,
  triggerOnce = true,
  className,
  fallback,
}: IntersectionObserverProps) {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [hasTriggered, setHasTriggered] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const isVisible = entry.isIntersecting;
        setIsIntersecting(isVisible);

        if (isVisible && !hasTriggered) {
          onIntersect?.();
          setHasTriggered(true);
          
          if (triggerOnce) {
            observer.disconnect();
          }
        }
      },
      {
        rootMargin,
        threshold,
      }
    );

    observer.observe(element);

    return () => observer.disconnect();
  }, [onIntersect, rootMargin, threshold, triggerOnce, hasTriggered]);

  const shouldShowContent = !triggerOnce || hasTriggered || isIntersecting;

  return (
    <div ref={elementRef} className={className}>
      {shouldShowContent ? children : fallback}
    </div>
  );
}

// Custom hook for intersection observer
export function useIntersectionObserver(
  options: {
    rootMargin?: string;
    threshold?: number | number[];
    triggerOnce?: boolean;
  } = {}
) {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [hasIntersected, setHasIntersected] = useState(false);
  const elementRef = useRef<HTMLElement>(null);

  const {
    rootMargin = '0px',
    threshold = 0.1,
    triggerOnce = true,
  } = options;

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const isVisible = entry.isIntersecting;
        setIsIntersecting(isVisible);

        if (isVisible && !hasIntersected) {
          setHasIntersected(true);
          
          if (triggerOnce) {
            observer.disconnect();
          }
        }
      },
      {
        rootMargin,
        threshold,
      }
    );

    observer.observe(element);

    return () => observer.disconnect();
  }, [rootMargin, threshold, triggerOnce, hasIntersected]);

  return {
    elementRef,
    isIntersecting,
    hasIntersected,
  };
}