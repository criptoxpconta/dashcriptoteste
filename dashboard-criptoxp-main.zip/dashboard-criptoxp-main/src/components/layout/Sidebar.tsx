import { useAuth } from '@/hooks/useAuth';
import { NavLink, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  BarChart3, 
  Users, 
  TrendingUp, 
  Receipt, 
  Settings, 
  LogOut,
  PieChart,
  Briefcase,
  Minus,
  Home,
  MessageSquare
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useEffect, useState } from 'react';

export function Sidebar() {
  const { profile, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();

  const investorNavItems = [
    { href: '/app/investidor', label: 'Dashboard', icon: BarChart3 },
    { href: '/app/investidor/criptoxp-ia', label: 'CriptoXP IA', icon: PieChart },
    { href: '/app/investidor/resultados', label: 'Resultados', icon: TrendingUp },
    { href: '/app/investidor/operacoes', label: 'Operações', icon: Briefcase },
    { href: '/app/investidor/transacoes', label: 'Transações', icon: Receipt },
  ];

  const adminNavItems = [
    { href: '/app/admin', label: 'Dashboard', icon: Home },
    { href: '/app/admin/investors', label: 'Investidores', icon: Users },
    { href: '/app/admin/operations', label: 'Operações', icon: Briefcase },
    { href: '/app/admin/results', label: 'Resultados', icon: TrendingUp },
    { href: '/app/admin/transactions', label: 'Transações', icon: Receipt },
    { href: '/app/admin/withdrawals', label: 'Saques', icon: Minus },
    { href: '/app/admin/manage-assets', label: 'Gerenciar Ativos', icon: PieChart },
  ];

  const navItems = isAdmin ? adminNavItems : investorNavItems;

  const [open, setOpen] = useState(false);
  useEffect(() => {
    const handleRoute = () => setOpen(false);
    window.addEventListener('hashchange', handleRoute);
    window.addEventListener('popstate', handleRoute);
    return () => {
      window.removeEventListener('hashchange', handleRoute);
      window.removeEventListener('popstate', handleRoute);
    };
  }, []);

  const NavList = () => (
    <nav className="flex flex-col gap-1 lg:gap-2">
      {navItems.map((item) => (
        <NavLink
          key={item.href}
          to={item.href}
          className={({ isActive }) =>
            cn(
              "flex items-center gap-2 lg:gap-3 px-2 lg:px-3 py-2 rounded-lg text-xs lg:text-sm transition-colors hover:bg-accent hover:text-accent-foreground",
              isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground"
            )
          }
        >
          <item.icon className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );

  return (
    <>
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex fixed left-0 top-0 h-screen w-64 flex-col border-r border-border bg-card p-4">
        <div className="mb-6">
          <div className="text-sm text-muted-foreground">Olá,</div>
          <div className="font-semibold">{profile?.nome ?? profile?.email}</div>
        </div>

        <NavList />

        <div className="mt-auto space-y-1 lg:space-y-2 border-t border-border pt-4">
          <NavLink
            to="/app/settings"
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 lg:gap-3 px-2 lg:px-3 py-2 rounded-lg text-xs lg:text-sm transition-colors hover:bg-accent hover:text-accent-foreground",
                isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground"
              )
            }
          >
            <Settings className="h-4 w-4 flex-shrink-0" />
            <span className="truncate">Configurações</span>
          </NavLink>

          <Button
            variant="ghost"
            className="w-full justify-start gap-2 lg:gap-3"
            onClick={async () => {
              await signOut();
              navigate("/login");
            }}
          >
            <LogOut className="h-4 w-4" />
            Sair
          </Button>
        </div>
      </aside>

      {/* Bottom Nav Mobile - com z-index alto e safe-area */}
      <div
        id="mobile-bottom-nav"
        className="lg:hidden fixed inset-x-0 bottom-0 z-50 border-t border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60"
        style={{ WebkitTapHighlightColor: 'transparent' }}
      >
        <nav className="grid grid-cols-5 gap-1 px-2 pt-2 pb-[calc(env(safe-area-inset-bottom)+10px)] pointer-events-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.href}
              to={item.href}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center gap-1 py-2 rounded-md transition-colors hover:bg-accent hover:text-accent-foreground",
                  isActive ? "text-primary" : "text-muted-foreground"
                )
              }
            >
              <item.icon className="h-5 w-5" />
              <span className="text-[11px] font-medium text-center leading-tight">{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </div>
    </>
  );
}
