import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { useTheme } from 'next-themes';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Settings, LogOut, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import OptimizedImage from '@/components/ui/optimized-image';

export function Header() {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const { theme } = useTheme();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const getUserInitials = () => {
    if (profile?.full_name) {
      return profile.full_name.charAt(0).toUpperCase();
    }
    if (profile?.username) {
      return profile.username.charAt(0).toUpperCase();
    }
    if (user?.email) {
      return user.email.charAt(0).toUpperCase();
    }
    return 'U';
  };

  const getRoleLabel = () => {
    if (profile?.role === 'admin') return 'Administrador';
    if (profile?.role === 'investor') return 'Investidor';
    return '';
  };

  return (
    <header className="h-14 lg:h-16 border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
      <div className="flex items-center justify-between h-full mobile-safe-area">
        <div className="flex items-center gap-2 lg:gap-4 min-w-0">
          <Button variant="ghost" onClick={() => navigate('/')} className="p-1 lg:p-2 flex-shrink-0">
            <OptimizedImage 
              src={theme === 'dark' ? "/lovable-uploads/dfef5ea2-b978-4f62-b3d6-c196967882a7.png" : "/lovable-uploads/a62c4ed4-d657-4d7a-b950-74e68e753e60.png"}
              alt="CriptoXP"
              className="h-6 lg:h-8 w-auto"
              priority={true}
            />
          </Button>
          <h1 className="text-sm lg:text-xl font-semibold truncate">
            {profile?.role === 'admin' ? 'Painel Admin' : 'Dashboard'}
          </h1>
        </div>

        <div className="flex items-center gap-1 lg:gap-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate(profile?.role === 'admin' ? '/app/admin' : '/app/investidor')}
            className="hidden sm:flex text-xs lg:text-sm"
          >
            Home
          </Button>
          
          <ThemeToggle />
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 lg:h-10 lg:w-10 rounded-full touch-target">
                <Avatar className="h-8 w-8 lg:h-10 lg:w-10">
                  <AvatarImage 
                    src={profile?.avatar_url || ''} 
                    alt={profile?.full_name || profile?.username || user?.email || 'Avatar'}
                    loading="lazy"
                  />
                  <AvatarFallback className="bg-primary text-primary-foreground text-xs lg:text-sm">
                    {getUserInitials()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-48 lg:w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none truncate">
                    {profile?.full_name || profile?.username || user?.email}
                  </p>
                  <p className="text-xs leading-none text-muted-foreground truncate">
                    {user?.email}
                  </p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {getRoleLabel()}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/')} className="touch-target">
                <User className="mr-2 h-4 w-4" />
                <span>Página Inicial</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/app/settings')} className="touch-target">
                <Settings className="mr-2 h-4 w-4" />
                <span>Configurações</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/app/investidor/suporte')} className="touch-target">
                <Settings className="mr-2 h-4 w-4" />
                <span>Suporte</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="touch-target">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Sair</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}