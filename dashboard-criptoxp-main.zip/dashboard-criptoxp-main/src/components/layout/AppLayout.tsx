import { useAuth } from '@/hooks/useAuth';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';

export function AppLayout() {
  const { user, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Redirect to appropriate dashboard based on role
  if (location.pathname === '/app') {
    if (profile?.role === 'admin') {
      return <Navigate to="/app/admin" replace />;
    } else if (profile?.role === 'investor') {
      return <Navigate to="/app/investidor" replace />;
    }
  }

  return (
    <div className="min-h-screen bg-background safe-top safe-bottom">
      <div className="flex flex-col lg:flex-row">
        <Sidebar />
        <div className="flex-1 lg:ml-64 min-w-0">
          <Header />
          <main className="mobile-container py-4 lg:p-6 pb-20 lg:pb-6 safe-bottom">
            <div className="fade-in visible">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}