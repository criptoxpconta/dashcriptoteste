interface StructuredDataProps {
  type: 'website' | 'organization' | 'service';
  data?: Record<string, any>;
}

const StructuredData = ({ type, data = {} }: StructuredDataProps) => {
  const getStructuredData = () => {
    const baseData = {
      "@context": "https://schema.org",
      "@type": type === 'website' ? "WebSite" : type === 'organization' ? "Organization" : "Service",
    };

    switch (type) {
      case 'website':
        return {
          ...baseData,
          name: "CriptoXP",
          url: "https://criptoxp.com",
          description: "Plataforma completa para gestão de criptoativos com análise de performance, dashboards intuitivos e segurança total.",
          potentialAction: {
            "@type": "SearchAction",
            target: {
              "@type": "EntryPoint",
              urlTemplate: "https://criptoxp.com/search?q={search_term_string}"
            },
            "query-input": "required name=search_term_string"
          },
          ...data
        };

      case 'organization':
        return {
          ...baseData,
          name: "CriptoXP",
          url: "https://criptoxp.com",
          logo: "https://criptoxp.com/lovable-uploads/d195b217-fce3-4ad0-ad1d-cfe372317188.png",
          description: "Plataforma de gestão de criptoativos com tecnologia avançada para investidores e gestores profissionais.",
          contactPoint: {
            "@type": "ContactPoint",
            contactType: "customer service",
            availableLanguage: "Portuguese"
          },
          ...data
        };

      case 'service':
        return {
          ...baseData,
          name: "Gestão de Criptoativos",
          provider: {
            "@type": "Organization",
            name: "CriptoXP"
          },
          description: "Serviço completo de gestão e análise de investimentos em criptoativos com dashboards profissionais e relatórios em tempo real.",
          category: "Financial Services",
          ...data
        };

      default:
        return baseData;
    }
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(getStructuredData())
      }}
    />
  );
};

export default StructuredData;